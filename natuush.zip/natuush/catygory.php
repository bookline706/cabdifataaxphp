<?php
	session_start();
	require "php/db.php";
	require_once "php/function.php";
  require "php/component.php";
  
	$user = new login_registration_class();
 
 
  if(isset($_POST["haert"]))  
  {  
      $name = $_POST['name'];
      $price = $_POST['price'];
      $usern = $_POST['username'];
     
      if(empty($name))
      {

    
       echo '<script>alert("filed")</script>';  
       
      }
      else{

       $cart= $user->show_heart($name,$price,$usern);
   
       if($cart){
       echo '<script>alert("your liked this product thank you")</script>'; 
       header("Location: index.php");
       exit();
  
      }
  }  }

  if(isset($_POST["add"]))  
  {  
      $name = $_POST['name'];
      $price= $_POST['price'];
      $qty=1;
      $usern = $_POST['username'];
     
      if(empty($name))
      {

    
       echo '<script>alert("filed")</script>';  
       
      }
      else{

       $cart= $user->show_cart($name,$price,$qty,$usern);
   
       if($cart){
       echo '<script>alert("Product Is Added Your Cart")</script>'; 
       header("Location: index.php");
       exit();
  
      }else{
       echo '<script>alert("This Product is Already into Your Cart")</script>';  
       header("Location: index.php");
       exit();

      }
  }  }
 
  

    ?>
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.2.19/tailwind.min.css" integrity="sha512-wnea99uKIC3TJF7v4eKk4Y+lMz2Mklv18+r4na2Gn1abDRPPOeef95xTzdwGD9e6zXJBteMIhZ1+68QC5byJZw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@200;300;400;600;700&family=Poppins:wght@300;400;500;600&family=Roboto:wght@100;300;400;500;700&family=Satisfy&display=swap" rel="stylesheet">

  <!----  <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css">-->
    
 
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css">

     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.13.6/css/selectize.bootstrap5.css">
     <link rel="stylesheet" href="glider min/glider.min.css"/>
    <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <link rel="stylesheet" href="style.css">

    <?php
  include "php/header.php";
  include "php/header-top.php";
  $catygory = $_SESSION['catygory'];
  if(isset($_REQUEST['catygory'])){
    $catygory = $_REQUEST['catygory'];
  }


    ?>                      
            <section class="foods" style="margin-top:5rem;" id="food">
           
           
         
           <div class="food">
            
            </div>
     <div class="container productss list">
     <!--  -->
    
            <?php
                
                
  if (isset($_SESSION['id']) && isset($_SESSION['user'])) {
    $username = $_SESSION['user'];
  
                $result = $user-> show_catygory($catygory);
                if($result){
                while($row = $result->fetch_assoc()){
                    
?>
                  <div class="row row-222 item" style="width:12rem;">
                  <div class="row-1" style="padding-top: 1rem;">
                  <form action="index.php" method="post" enctype="multipart/form-data"> 
                      <a href="productv.php?id=<?php echo $row['id']?>" > <img class="image-item ac" src="data:image/jpg;base64,<?php echo base64_encode($row['img1'])?>" alt="Image1" class="img-fluid card-img-top"></a>
                  
                      <a href="productv.php?id=<?php echo $row['id']?>" > <img class="image-item none" src="data:image/jpg;base64,<?php echo base64_encode($row['img2'])?>" alt="Image1" class="img-fluid card-img-top"></a>
                          <div class="food_icon">
                             
                          <button type="submit" name="haert" style="background:none;"><i class="fas fa-heart"></i></button>

                              <a href="productv.php?id=<?php echo $row['id']?>" >  <i class="fas fa-eye"></i> </a>
                              
                              
                          </div>
                      
                  </div>
                  <div class="footer_food">
                  <div class="item-name">
                  <h4 class="title-item"><?php echo $row['name']?></h4>
                  </div>
                  
                  <div class="price-items">
                  <h2 class="price"> Price:</h2>
                  <h2 class="price-item">$<?php echo $row['price']?></h2>
                  </div>
                  </div>
                  <input type="hidden" name="username" id="" value="<?php echo $_SESSION['user']?>">

                  
                  <input type="hidden" name="name" id="" value=" <?php echo $row['name']?>">
                  <input type="hidden" name="price" id="" value="<?php echo $row['price']?>">
                  <button type="submit" class="btn btn-warning my-2" style="margin:.7rem ; width:10rem; margin-right:1rem;" name="add">Add to Cart <i class="fas fa-shopping-cart"></i></button>
                  <input type="hidden" name="food_id" value="<?php echo $row['id']?>">
                  </div> </form>
                  <?php
                                    }
                                 

                }
                    else{
                        ?>
                        <span class="noproduct-for-catygory"style="color:red; font-size:2rem;">No Product Here........................</span>
                        <?php
                    }
                  }
                    else{
                      $result = $user-> show_catygory($catygory);
                      if($result){
                      while($row = $result->fetch_assoc()){
                          
                          component($row['name'], $row['price'], base64_encode($row['img1']),  base64_encode($row['img2']), $row['id']);
                          }
                      }
                          else{
                              ?>
                              <span class="noproduct-for-catygory"style="color:red; font-size:2rem;">No Product Here........................</span>
                              <?php
                          }
                    }
                ?>
                </div>
                     <ul class="listPage">

</ul>
  </section><?php
     /*         
if (isset($_POST['add'])){
  //print_r($_POST['food_id']);
  if(isset($_SESSION['cart'])){

      $item_array_id = array_column($_SESSION['cart'], "food_id");

      if(in_array($_POST['food_id'], $item_array_id)){
      
      }else{

          $count = count($_SESSION['cart']);
          $item_array = array(
              'food_id' => $_POST['food_id']
          );

          $_SESSION['cart'][$count] = $item_array;
      }
    

  }else{

      $item_array = array(
              'food_id' => $_POST['food_id']
      );

      // Create new session variable
      $_SESSION['cart'][0] = $item_array;
      print_r($_SESSION['cart']);
  }
}
*/
                ?>

                   
          <script>
                  const thumbimg = document.querySelector(".img").children;
                function changeImages(event){
                    console.log(event.children[0]);
                document.querySelector(".home-img").src=event.children[0].src
                for (var i=0; i < thumbimg.length; i++)
                  {
            thumbimg[i].classList.remove('activeimg');
            }
            event.classList.add('activeimg');
            
        }
          </script>
       
          
     
      






<?php
include "php/footer.php";
?>