
<?php
	session_start();
	require "php/db.php";
	require_once "php/function.php";
  require "php/component.php";
  
	$user = new login_registration_class();

include "php/header.php";
include "php/header-top.php";
$errors = array();
  // ... 
        ?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@200;300;400;600;700&family=Poppins:wght@300;400;500;600&family=Roboto:wght@100;300;400;500;700&family=Satisfy&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css">
    
 
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css">



    <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <link rel="stylesheet" href="style.css">
    <title>Customer login</title>
</head>

<nav class="nave-1">
        <i class="fas fa-bars" aria-hidden="true" id="menu-toggle"></i></i>
        
       <h4>DIIRIYE STORE</h4>
    </nav>
<body class="body-1">
  
    <div class="row">
        <style>
            footer{
                margin-top:2rem;
            }
            .body-1{
  background-color: rgb(255, 166, 83);
  padding: none;
  margin: none;
}
.row{
  width: 100%;
}
 .conn{
  padding: 2.5rem;
  background: #fff;
  border-radius: .5rem;
  width: 25rem;
  position: relative;
  overflow: hidden;
  text-align: center;
  box-shadow: 0px  2px 40px rgb(0, 0, 0);
 margin-top: 7rem;
  
}
body.active .conn {
    background:    var(--black-1-);

}
.row form{
    margin-bottom:2rem;
}
.row form .row-11{
 padding: 3rem;
}
.row form .row-11 .col-md-12{
  padding-top: 1rem;
  display: flex;
}
.row form .row-11 .col-md-12 i{
 font-size: 1.5rem;
 color:  var(--swich-color);
 padding: .3rem;
}
.row form .row-11 .col-md-12 button{
  margin-left: 5rem;
  background-color:  var(--swich-color);
  color: white;
  border: none;
  padding: .5rem;
  border-radius: .2rem;
  outline: none;
}
.row form .row-11 .col-md-12 input{
  border: 1px solid  var(--swich-color);
  outline: rgb(255, 166, 83);
}
body.active .conn h3{
    color: white;
}
        </style>     
		
    <form action="" method="post">
   
        <div class="container conn">
        <h3>Registeration</h3>
       
       
     	
            <div class="row">
            <?php
            
// REGISTER USER
if (isset($_POST['register'])) {
    // receive all input values from the form
    $name = $_POST['name'];
    $email = $_POST['email'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $password_1 = $_POST['password1'];


    // form validation: ensure that the form is correctly filled ...
    // by adding (array_push()) corresponding error unto $errors array
    if (empty($name)) { array_push($errors, "name is required"); }
    if (empty($username)) { array_push($errors, "Username is required"); }
    if (empty($email)) { array_push($errors, "Email is required"); }
    
    if (empty($password)) { array_push($errors, "Password is required"); }
    if ($password!= $password_1) {
      array_push($errors, "The two passwords do not match");
    } 
  
    // first check the database to make sure 
    // a user does not already exist with the same username and/or email
    $user_check_query = "SELECT * FROM login WHERE username='$username' OR email='$email'  LIMIT 1";
    $result = mysqli_query($conn, $user_check_query);
    $users = mysqli_fetch_assoc($result);
    
    if ($users) { // if users exists
      if ($users['username'] === $username) {
        array_push($errors, "usersname already exists");
      }
  
      if ($users['email'] === $email) {
        array_push($errors, "email already exists");
      }
    
    }
  
    // Finally, register user if there are no errors in the form
    if (count($errors) == 0) {
       // $password = md5($password_1);//encrypt the password before saving in the database
  
        $query = "INSERT INTO `login`(`name`, `email`, `username`, `password`) VALUES ('$name','$email','$username','$password')"; 

        mysqli_query($conn, $query);
       
       echo"<script>window.location.href = 'login.php'</script>";
    }
  }
  
              if (count($errors) > 0) : ?>
  <div class="error">
  	<?php foreach ($errors as $error) : ?>
  	  <p><?php echo $error ?></p>
  	<?php endforeach ?>
  </div>
<?php  endif ?>
                <div class="row-11">
                
                <a href="login.php" style="background: blue; color:#fff;padding:.5rem; margin-bottom:.5rem; border:.5rem; text-align:center;">Loging</a>

                <div class="col-md-12">
             
                        <input name="name" type="text"  placeholder="Your name" style="padding-left:.5rem;">
                    </div>
                <div class="col-md-12">
            
                <input name="email" type="email"  placeholder="email" style="padding-left:.5rem;">
                    </div>
                   
                    <div class="col-md-12">
                                  <input name="username" type="text"  placeholder="Username"  style="padding-left:.5rem;">
                    </div>
                    <div class="col-md-12">
                    
                   
                        <input name="password" type="password"  placeholder="Password"  style="padding-left:.5rem;">
                    </div>
                    <div class="col-md-12">
                    
                   
                        <input name="password1" type="password"  placeholder="config password"  style="padding-left:.5rem;">
                    </div>
                    <div class="col-md-12">
                        <button type="submit" name="register" value="submit">submit</button>
                    </div>
                   
                </div>
            </div>
        </div>
    </form>

</div> 
<!----sript links-->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/morris.js/0.2.7/morris.min.js" integrity="sha512-nF4mXN+lVFhVGCieWAK/uWG5iPru9+/z1iz0MJbYTto85I/k7gmbTFFFNgU+xVRkF0LI2nRCK20AhxFIizNsXA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/morris.js/0.2.7/morris.js" integrity="sha512-3xPxgu7YfKOmybTrSNe7SjV0nGM21Boq0j66hGKFgeeg124xGBvQ8XXaQJ2ti/QZT4xtd5mCo/eh8JxURWidtA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
  

      <?php
  include_once "php/footer.php";
?>