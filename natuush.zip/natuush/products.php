const products = [
    {
      idnumer: 1,
      id: 0,
      name: "Cake",
      price: 29.99,
      instock: 100,
      description:
        "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Asperiores, error.",
      imgSrc: "./imag/cake.jpg",
      imgSrc1: "./imag/ice_cream.jpg",
    },
    {
      
    
      idnumer: 1,
        id: 1,
        name: "Chocolate Drink ",
        price: 29.99,
        instock: 100,
        description:
          "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Asperiores, error.",
        imgSrc: "./imag/chocolate_Drink.jpg",
      },
      {
        idnumer: 1,
        id: 2,
        name: "Ice crean",
        price: 29.99,
        instock: 100,
        description:
          "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Asperiores, error.",
          imgSrc: "./imag/ice_cream.jpg",
      },
      {
        idnumer: 1,
        id: 3,
        name: "Juice",
        price:29.99,
        instock: 100,
        description:
          "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Asperiores, error.",
          imgSrc: "./imag/juse.jpg",
      },
      {
        idnumer: 1,
        id: 4,
        name: "Pizza Hot",
        price: 29.99,
        instock: 100,
        description:
          "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Asperiores, error.",
          imgSrc: "./imag/pizza.jpg",
      },
      {
        idnumer: 1,
        id: 5,
        name: "Chocolate",
        price: 29.99,
        instock: 100,
        description:
          "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Asperiores, error.",
          imgSrc: "./imag/chocolate.jpg",
      },
      {
        idnumer: 1,
        id: 6,
        name: "Cake",
        price: 29.99,
        instock: 100,
        description:
          "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Asperiores, error.",
        imgSrc: "./imag/cake.jpg",
      },
      {
        
      
        idnumer: 1,
          id: 7,
          name: "Chocolate Drink ",
          price: 29.99,
          instock: 100,
          description:
            "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Asperiores, error.",
          imgSrc: "./imag/chocolate_Drink.jpg",
        },
        {
          idnumer: 1,
          id: 8,
          name: "Ice crean",
          price: 29.99,
          instock: 100,
          description:
            "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Asperiores, error.",
            imgSrc: "./imag/ice_cream.jpg",
        },
        {
          idnumer: 1,
          id: 9,
          name: "Juice",
          price:29.99,
          instock: 100,
          description:
            "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Asperiores, error.",
            imgSrc: "./imag/juse.jpg",
        },
        {
          idnumer: 1,
          id: 10,
          name: "Pizza Hot",
          price: 29.99,
          instock: 100,
          description:
            "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Asperiores, error.",
            imgSrc: "./imag/pizza.jpg",
        },
        {
          idnumer: 1,
          id: 11,
          name: "Chocolate",
          price: 29.99,
          instock: 100,
          description:
            "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Asperiores, error.",
            imgSrc: "./imag/chocolate.jpg",
        }
        ,
        {
          idnumer: 1,
          id: 12,
          name: "Cake",
          price: 29.99,
          instock: 100,
          description:
            "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Asperiores, error.",
          imgSrc: "./imag/cake.jpg",
        },
        {
          
        
          idnumer: 1,
            id: 13,
            name: "Chocolate Drink ",
            price: 29.99,
            instock: 100,
            description:
              "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Asperiores, error.",
            imgSrc: "./imag/chocolate_Drink.jpg",
          },
          {
            idnumer: 1,
            id: 14,
            name: "Ice crean",
            price: 29.99,
            instock: 100,
            description:
              "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Asperiores, error.",
              imgSrc: "./imag/ice_cream.jpg",
          },
          {
            idnumer: 1,
            id: 15,
            name: "Juice",
            price:29.99,
            instock: 100,
            description:
              "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Asperiores, error.",
              imgSrc: "./imag/juse.jpg",
          },
          {
            idnumer: 1,
            id: 16,
            name: "Pizza Hot",
            price: 29.99,
            instock: 100,
            description:
              "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Asperiores, error.",
              imgSrc: "./imag/pizza.jpg",
          },
          {
            idnumer: 1,
            id: 17,
            name: "Chocolate",
            price: 29.99,
            instock: 100,
            description:
              "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Asperiores, error.",
              imgSrc: "./imag/chocolate.jpg",
          }
    
];


const prodcutView =[

  {
    idnumer: 1,
    id: 1,
    name: "T-shirt gjgg",
    price: 29.99,
    instock: 100,
    description:
      "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Asperiores, error.",
    imgSrc: "./image/bg.jpg",
    imgSrc1: "./image/Screenshot 2022-12-10 025552.jpg",
    imgSrc2: "./image/Screenshot 2022-12-10 025552.jpg",
    imgSrc3: "./image/Screenshot 2022-12-10 025552.jpg",
    imgSrc4: "./image/Screenshot 2022-12-10 025552.jpg",
  }
];

const CartCleer =
[
  {
  idnumer: 1,
  name: "Your Cart"
  }
]


const Oder =
[
  {
  idnumer: 1,
  name: "Oder"
  }
]







<script>
  
 <script>
      const products = [
    <?php

//$db = new PDO('mysql:host=localhost; dbname=natuush','root','');
$db = mysqli_connect('localhost', 'root', '', 'natuush');
//$result = $conn->query($sql);

    $sql = ('select * from product where bestseler=3');
$result = $db->query($sql);
	
  
   
   while($im = $result->fetch_assoc()){
  ?>
    {
    
      idnumer: 1,
      id: 0,
      name: "jkhkjlo",
      price: 29.99,
      instock: 100,
      description:
        "<?php echo base64_encode($im['desc']); ?>",
      imgSrc: " data:image/jpg;charset=utf8;base64,<?php echo base64_encode($im['img1']); ?>",
      imgSrc1: " data:image/jpg;charset=utf8;base64,<?php echo base64_encode($im['img2']); ?>",
    
    },
     <?php
}
   


?>
];
  

const prodcutView =[

  {
    idnumer: 1,
    id: 1,
    name: "T-shirt gjgg",
    price: 29.99,
    instock: 100,
    description:
      "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Asperiores, error.",
    imgSrc: "./image/bg.jpg",
    imgSrc1: "./image/Screenshot 2022-12-10 025552.jpg",
    imgSrc2: "./image/Screenshot 2022-12-10 025552.jpg",
    imgSrc3: "./image/Screenshot 2022-12-10 025552.jpg",
    imgSrc4: "./image/Screenshot 2022-12-10 025552.jpg",
  }
];

const CartCleer =
[
  {
  idnumer: 1,
  name: "Your Cart"
  }
]


const Oder =
[
  {
  idnumer: 1,
  name: "Oder"
  }
]











 </script>
</script>





