<?php
	session_start();
	require "php/db.php";
	require_once "php/function.php";
  require "php/component.php";
  
	$user = new login_registration_class();


 
  if(isset($_POST["haert"]))  
  {  
      $name = $_POST['name'];
      $price = $_POST['price'];
      $usern = $_POST['username'];
     
      if(empty($name))
      {

    
       echo '<script>alert("filed")</script>';  
       
      }
      else{

       $cart= $user->show_heart($name,$price,$usern);
   
       if($cart){
       echo '<script>alert("your liked this product thank you")</script>'; 
       header("Location: index.php");
       exit();
  
      }
  }  }

  if(isset($_POST["add"]))  
  {  
      $name = $_POST['name'];
      $price= $_POST['price'];
      $qty=1;
      $usern = $_POST['username'];
     
      if(empty($name))
      {

    
       echo '<script>alert("filed")</script>';  
       
      }
      else{

       $cart= $user->show_cart($name,$price,$qty,$usern);
   
       if($cart){
       echo '<script>alert("Product Is Added Your Cart")</script>'; 
       header("Location: index.php");
       exit();
  
      }else{
      ?>
      <h3>This Product is Already into Your Cart</h3>
      <?php
       header("Location: index.php");
       exit();

      }
  }  }
 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.2.19/tailwind.min.css" integrity="sha512-wnea99uKIC3TJF7v4eKk4Y+lMz2Mklv18+r4na2Gn1abDRPPOeef95xTzdwGD9e6zXJBteMIhZ1+68QC5byJZw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@200;300;400;600;700&family=Poppins:wght@300;400;500;600&family=Roboto:wght@100;300;400;500;700&family=Satisfy&display=swap" rel="stylesheet">

  <!----  <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css">-->
    
 
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css">

     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.13.6/css/selectize.bootstrap5.css">
     <link rel="stylesheet" href="glider min/glider.min.css"/>
    <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <link rel="stylesheet" href="style.css">

    <title>Natuush</title>
    <style>
      body.active .dropdown-content a:hover{
    background-color: rgb(27, 26, 26);
}
    </style>
</head>
<?php
  include "php/header.php";
  include "php/header-top.php";

?>


           <section class="home"id="home">
         <!----  <div class="bng">
              <h3>Natuush</h3>
              <p>Natuush resturant You can find different foods such as:
                rice, chicken,tea,etc.</p>
                <button>Contact Us</button>
           </div>--->
           <div class="shape"></div>
           </section>
        
          
        <style>
          .fixed-img{
            position: fixed;
            z-index: 1000;
            background:white;
            height: 20rem;
            width: 10rem;
          }
        </style>
    <section class="fixed-img" style="position:fixed; height: 100%; width: 100%; z-index: 199;">

    </section>
    <section class="swiper mySwiper" style="position: relative; ">
            <div class="food">
                <center> <h3>Top Sellers</h3></center>
             </div>
          
            <div class="glider-contain">
                <button aria-label="Previous" class="glider-prev">«</button>
                <button aria-label="Next" class="glider-next">»</button>
                <div class="glider">
                <?php 
                                  
  if (isset($_SESSION['id']) && isset($_SESSION['user'])) {
    $username= $_SESSION['user'];
             $result = $user-> getproductid();
             if($result){
             while($row = $result->fetch_assoc()){
                 ?>
                 <div class=""  style="width:14rem;">
               <div class="row row-222 item" style="width:14rem;">
                  <div class="row-1" style="padding-top: 1rem;">
                  <form action="index.php" method="post" enctype="multipart/form-data"> 
                      <a href="productv.php?id=<?php echo $row['id']?>" > <img class="image-item ac" src="data:image/jpg;base64,<?php echo base64_encode($row['img1'])?>" alt="Image1" class="img-fluid card-img-top"></a>
                  
                      <a href="productv.php?id=<?php echo $row['id']?>" > <img class="image-item none" src="data:image/jpg;base64,<?php echo base64_encode($row['img2'])?>" alt="Image1" class="img-fluid card-img-top"></a>
                          <div class="food_icon">
                             
                              <button type="submit" name="haert" style="background:none;"><i class="fas fa-heart"></i></button>
                              <a href="productv.php?id=<?php echo $row['id']?>" >  <i class="fas fa-eye"></i> </a>
                              
                              
                          </div>
                      
                  </div>
                  <div class="footer_food">
                  <div class="item-name">
                  <h4 class="title-item"><?php echo $row['name']?></h4>
                  </div>
                  
                  <div class="price-items">
                  <h2 class="price"> Price:</h2>
                  <h2 class="price-item">$<?php echo $row['price']?></h2>
                  </div>
                  </div>
                
                  <input name="username" id="" type="hidden" value="<?php echo $_SESSION['user']?>">

                  
                  <input type="hidden" name="name" id="" value=" <?php echo $row['name']?>">
                  <input type="hidden" name="price" id="" value="<?php echo $row['price']?>">
                  <button type="submit" class="btn btn-warning my-2" style="margin:.7rem ; width:10rem; margin-right:1rem;" name="add">Add to Cart <i class="fas fa-shopping-cart"></i></button>
                  <input type="hidden" name="food_id" value="<?php echo $row['id']?>">
                  </div> </form></div> 
                  
                  <?php
             }
            }
          }else
          {
            ?>
            <?php
             $result = $user-> getproductid();
             if($result){
             while($row = $result->fetch_assoc()){
                 ?>
                 <div class=""  style="width:14rem;">
               <div class="row row-222 item" style="width:14rem;">
                  <div class="row-1" style="padding-top: 1rem;">
                  <form action="index.php" method="post" enctype="multipart/form-data"> 
                      <a href="productv.php?id=<?php echo $row['id']?>" > <img class="image-item ac" src="data:image/jpg;base64,<?php echo base64_encode($row['img1'])?>" alt="Image1" class="img-fluid card-img-top"></a>
                  
                      <a href="productv.php?id=<?php echo $row['id']?>" > <img class="image-item none" src="data:image/jpg;base64,<?php echo base64_encode($row['img2'])?>" alt="Image1" class="img-fluid card-img-top"></a>
                          <div class="food_icon">
                             
                              <a href="register.php"><i class="fas fa-heart"></i></a>
                              <a href="productv.php?id=<?php echo $row['id']?>" >  <i class="fas fa-eye"></i> </a>
                              
                              
                          </div>
                      
                  </div>
                  <div class="footer_food">
                  <div class="item-name">
                  <h4 class="title-item"><?php echo $row['name']?></h4>
                  </div>
                  
                  <div class="price-items">
                  <h2 class="price"> Price:</h2>
                  <h2 class="price-item">$<?php echo $row['price']?></h2>
                  </div>
                  </div>
                

                  
                  <input type="hidden" name="name" id="" value=" <?php echo $row['name']?>">
                  <input type="hidden" name="price" id="" value="<?php echo $row['price']?>">
                <a href="register.php">  <button type="submit" class="btn btn-warning my-2" style="margin:.7rem ; width:10rem; margin-right:1rem;" name="">Add to Cart <i class="fas fa-shopping-cart"></i></button></a>
                  <input type="hidden" name="food_id" value="<?php echo $row['id']?>">
                  </div> </form></div> 
                  
                  <?php
             }
            }
          }
                  ?>
      
                </div>
              
               
                <div role="tablist" class="dots"></div>
              </div>
              <script src="glider min/glider.min.js"></script>

           
        </section>
        <script>
      new Glider(document.querySelector('.glider'), {
slidesToScroll: 1,
slidesToShow: 4,
draggable: true,
dots: '.dots',
arrows: {
prev: '.glider-prev',
next: '.glider-next'
},
responsive: [
{
  // screens greater than >= 775px
  breakpoint: 1200,
  settings: {
    // Set to `auto` and provide item width to adjust to viewport
    slidesToShow: 4,
    slidesToScroll: 2,
   
  }
},{
  // screens greater than >= 1024px
  breakpoint: 900,
  settings: {
    slidesToShow: 3,
    slidesToScroll: 1,
   
  }
},{
  // screens greater than >= 1024px
  breakpoint: 640,
  settings: {
    slidesToShow: 2,
    slidesToScroll: 1,
   
  }
},{
  // screens greater than >= 1024px
  breakpoint: 304,
  settings: {
    slidesToShow: 1.5,
    slidesToScroll: 1,
   
  }
},{
  // screens greater than >= 1024px
  breakpoint: 0,
  settings: {
    slidesToShow: 1,
    slidesToScroll: 1,
   
  }
}
]
});
    </script>
        <section class="foods" id="food">
           
           <input type="hidden" name="name" value="">
         
            <div class="food">
  

                <center> <h3>Dishes</h3></center>
             </div>
      <div class="container productss list">
      <?php
                      
  if (isset($_SESSION['id']) && isset($_SESSION['user'])) {
    $username= $_SESSION['user'];
  
    if(isset($_REQUEST['catygory'])){
      $catygory = $_REQUEST['catygory'];
    }
  
                $result = $user-> get_all_products();
                if($result){
                while($row = $result->fetch_assoc()){
                    
?>
                  <div class="row row-222 item" style="width:12rem;">
                  <div class="row-1" style="padding-top: 1rem;">
                  <form action="index.php" method="post" enctype="multipart/form-data"> 
                      <a href="productv.php?id=<?php echo $row['id']?>" > <img class="image-item ac" src="data:image/jpg;base64,<?php echo base64_encode($row['img1'])?>" alt="Image1" class="img-fluid card-img-top"></a>
                  
                      <a href="productv.php?id=<?php echo $row['id']?>" > <img class="image-item none" src="data:image/jpg;base64,<?php echo base64_encode($row['img2'])?>" alt="Image1" class="img-fluid card-img-top"></a>
                          <div class="food_icon">
                             
                              <button type="submit" name="haert" style="background:none;"><i class="fas fa-heart"></i></button>
                              <a href="productv.php?id=<?php echo $row['id']?>" >  <i class="fas fa-eye"></i> </a>
                              
                              
                          </div>
                      
                  </div>
                  <div class="footer_food">
                  <div class="item-name">
                  <h4 class="title-item"><?php echo $row['name']?></h4>
                
                  </div>
                  
                  <div class="price-items">
                  <h2 class="price"> Price:</h2>
                  <h2 class="price-item">$<?php echo $row['price']?></h2>
                  </div>
                  </div>
                  <input name="username" id="" type="hidden" value="<?php echo $_SESSION['user']?>">

                  
                  <input type="hidden" name="name" id="" value=" <?php echo $row['name']?>">
                  <input type="hidden" name="price" id="" value="<?php echo $row['price']?>">
                  <button type="submit" class="btn btn-warning my-2" style="margin:.7rem ; width:10rem; margin-right:1rem;" name="add">Add to Cart <i class="fas fa-shopping-cart"></i></button>
                  <input type="hidden" name="food_id" value="<?php echo $row['id']?>">
                  </div> </form>
                  <?php
                                    }
                  

                }
                    else{
                        ?>
                        <span class="noproduct-for-catygory"style="color:red; font-size:2rem;">No Product Here........................</span>
                        <?php
                    }
                  }
                    else{
          
                $result = $user->get_all_products();
                if($result){
                while($row = $result->fetch_assoc()){
                  
                  component($row['name'], $row['price'], base64_encode($row['img1']),  base64_encode($row['img2']), $row['id']);

             ?>
                                 

                    
                          
                    
                        <?php
                }
              }
                else{
                  ?>
                  <span class="noproduct-for-catygory"style="color:red; font-size:2rem;">No Product Here........................</span>
                  <?php
              }
            }
            ?>
            </div>
      <ul class="listPage">

      </ul>
      
        </section>
      
        <style>
         
        </style>
        <section class="about" id="about">
            <div class="food">
               <center> <h3>About</h3></center>
            </div>
          
        <div class="swiper mySwiper home-slider">
    
    <div class="swiper-wrapper wrapp" style=" width: 100%; display:flex;">
      <?php

$result = $user-> get_all_about();
if($result){
while($row = $result->fetch_assoc()){
  ?>
      <div class=" abou-us  swiper-slide">
              <style>
                .scr{
                  height: 20rem;   overflow-y: scroll;
                 
                }
                .scr::-webkit-scrollbar{
    display: none;
}
                   .abou-us{
                    padding-bottom:7rem;
                   }
              </style>
      <div class="contents" >
                    <h3>Naduush</h3>
                    <div class="scr">
                    <p><?php echo $row['info']?></p>
</div>
                </div>
                 <div class="imgb">
                    <img src="data:image/jpg;base64,<?php echo base64_encode($row['image'])?>" style="border:none;" alt="">
                 </div>
                
            </div>
          
            <?php
}
}?>
             
          </div>
          <div class="shap" style=" margin-top:2rem;"></div>
        </div>
        </section>
        <script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
        <script>
          
var swiper = new Swiper(".home-slider", {
   spaceBetween:30,
 centeredslides:true,
autoplay:{
     delay:3000,
     desableOnInteration:false,
   },
pagination:
  {
     el: ".swiper-pagination",
     clickable: true,
    },
    loop:true
  });

        </script>
        <section class="Galery" id="Galery">
       

            <div class="food">
                <center> <h3>Galeries</h3></center>
             </div>
            <div class="imag lists-galery"  id="listPage">
            <?php
              $result = $user->getgaleryid();
              while($row = $result->fetch_assoc()){


              ?>

<img class="items" src="data:image/jpg;base64,<?php echo  base64_encode($row['name'])?>">
            <?php } ?>
            </div>
            <ul class="listPag">

            </ul>
        </section>
      
        <section class="contact" id="contact">
            <div class="food">
              <center>  <h3>Contact-Us</h3></center>
            </div>
            <div class="numbers">
            <?php
                 $result = $user->get_all_social();
                  if($result){
                 while($row = $result->fetch_assoc()){
                  ?> 
            
                <span class="number">
                <h3><?php echo $row['name']?></h3>
                          <a href="<?php echo $row['name']?>:<?php echo $row['link']?>"><?php echo $row['link']?></a>
                </span>
               <?php
                 }
                  }
                  $result = $user->get_all_numbers();
                  if($result){
                 while($row = $result->fetch_assoc()){
                  ?> 
                 
                      <span class="number">
                          <h3><?php echo $row['name']?></h3>
                          <a href="<?php echo $row['name']?>:<?php echo $row['link']?>"><?php echo $row['link']?></a>
                      </span>
                     <?php
                       }
                        }
                        ?>
                        </div>
            <div class="container container-1" >
               
                    <form action="" class="form-1" method="post" >
                      
                     <div class="img-waiter">
                        <img src="imag/img/waiter.jpg" alt="">
                     </div>
                      <div class="bg">
                      <?php 
                    if(isset($_POST['send'])){
                      $name = $_POST['fullname'];
                      $phone = $_POST['phone'];
                      $email = $_POST['email'];
                      $massage = $_POST['massege'];
                      if(empty($name) && empty($phone) && empty($email) && empty($massage)){
                        echo"no empty ";
                      }else{
                        $sql = $user->show_contact($name, $phone,  $email, $massage);
                        if($sql){
       echo '<script>alert("Thank For Contact Us")</script>'; 
  
      }else{
      
      }
                      }
                    }
               ?>
                        <input name="fullname" type="text" class="fullname" placeholder="Your Fullname" >
                        <input name="phone" type="text" class="phone" placeholder="Your Phone"><br>
                        <input name="email" type="text" class="email" placeholder="Your Email"><br>
                        <textarea name="massege" id="" cols="30" rows="10" placeholder="Your Massege">
                     
                           

                        </textarea>
                      <center>  <button type="submit" name="send" class="btn">Send Massege</button></center>
                    </div>
                    </form>
                   
            </div>
        </section>





     





      <?php
/*
           
if (isset($_POST['add'])){
  //print_r($_POST['food_id']);
  if(isset($_SESSION['cart'])){

      $item_array_id = array_column($_SESSION['cart'], "food_id");

      if(in_array($_POST['food_id'], $item_array_id)){
      
      }else{

          $count = count($_SESSION['cart']);
          $item_array = array(
              'food_id' => $_POST['food_id']
          );

          $_SESSION['cart'][$count] = $item_array;
      }
    

  }else{

      $item_array = array(
              'food_id' => $_POST['food_id']
      );

      // Create new session variable
      $_SESSION['cart'][0] = $item_array;
      print_r($_SESSION['cart']);
  }
}
*/
                ?>


    











  <!-----
<section class="oder-prodect" style="">
    <form action="" style=" display: grid;
  grid-template-columns: repeat(auto-fit, minmax(20rem,4fr));
  gap: 3rem;">
    <div class="container container-1 container-22">
       
        <div class="form-1 form-2" >
          <div class="bg">
            <input type="text" class="fullname" placeholder="Your Email" >
            <input type="text" class="phone" placeholder="Your Phone"><br>
            <input type="text" class="email" placeholder="Your Full Name"><br>
            <textarea name="" id="" cols="30" rows="10" placeholder="Your Massege">
         
               

            </textarea>
            <br><br>
          <center>  <button class="btn">Oder</button></center>
        </div>
       
    </div>
   
</div>
<div class="  content-item">
 
                      

</div>
    </form>
  </section>

-->

  
<?php
include_once "php/footer.php";

?>