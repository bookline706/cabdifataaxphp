<?php
	session_start();
	require "php/db.php";
	require_once "php/function.php";
  require "php/component.php";
  
	$user = new login_registration_class();

    if(isset($_REQUEST['id'])){
        $id = $_REQUEST['id'];
    }

  if (isset($_SESSION['id']) && isset($_SESSION['user'])) {
    $username= $_SESSION['user'];

?>

   

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.2.19/tailwind.min.css" integrity="sha512-wnea99uKIC3TJF7v4eKk4Y+lMz2Mklv18+r4na2Gn1abDRPPOeef95xTzdwGD9e6zXJBteMIhZ1+68QC5byJZw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@200;300;400;600;700&family=Poppins:wght@300;400;500;600&family=Roboto:wght@100;300;400;500;700&family=Satisfy&display=swap" rel="stylesheet">

  <!----  <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css">-->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

 
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css">

     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.13.6/css/selectize.bootstrap5.css">
     <link rel="stylesheet" href="glider min/glider.min.css"/>
    <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <link rel="stylesheet" href="style.css">
    <title>Natuush</title>
</head>
<?php
  include "php/header.php";
  include "php/header-top.php";
?>


<section class="cart-1 product_cart"id="cart">
           <div class="cart-all-items">
    
     <table class="table">
    
        <thead>
            <th>Name</th>
            <th>Price</th>
            <th>Quantity</th>
             <th>Delete</th>
        </thead>
     
        <?php
        if(isset($_POST['update'])){
            $name= $_POST['name'];
            $price = $_POST['price'];
            $qty = $_POST['qty'];
            $id = $_POST['id'];

            
            $sql = "UPDATE `cart` SET `id`='$id',`name`='$name',`price`='$price',`qty`='$qty',`user`='$username' WHERE id='$id' and user='$username'";

            if($conn->query($sql) === TRUE) {
              ?>
              <span style="  background-color: rgb(95, 207, 207); color:#fff;border-radius: .5rem; width: 100%; padding: .5rem;">Item is Updated</span>
              <?php
            }
        }
        
        if(isset($_POST['delete'])){
            $name= $_POST['name'];
            $price = $_POST['price'];
            $qty = $_POST['qty'];
            $id = $_POST['id'];
            $sql = "DELETE FROM `cart` WHERE id='$id' and user='$username'";
            
           
            if($conn->query($sql) === TRUE) {
                ?>
              <span style=" background-color: rgb(179, 116, 130); color:#fff; border-radius: .5rem; width: 100%; padding: .5rem;">Item is Deleted</span>
                <?php
            }
        }

$result = $user->get_all_car($username);
            while ($row = $result ->fetch_assoc()){
           ?>
            <form action="" method="post" class="cart-items">
                <input type="hidden" name="id" value="<?php echo $row['id']?>">
                <input type="hidden" name="name" value="<?php echo $row['name']?>">
                <input type="hidden" name="price" value="<?php echo $row['price']?>">
                
                
           <tr>
            <td>  <div class="name">
        <span><?php echo $row['name']?></span>
       </div></td>
       <td>
       <div class="price">
        <span>$<?php echo $row['price']?></span>
    </div>
       </td>
       <td>
        <div class="quantity">
            <i class="fas fa-plus plus plus<?php echo $row['id']?>"></i>
            <input type="text"class="qty qty<?php echo $row['id']?>" name="qty" value="<?php echo $row['qty']?>">
           <i class="fas fa-minus minus minus<?php echo $row['id']?>"></i>
           <button class="update" name="update"><i class="fas fa-refresh"></i></button>
        </div>
       </td>
       <td>
       <div class="acti">
    
      <button type="submit" name="delete">
        <i class="fas fa-close cart_remove"></i>
        </button>
    
      </div>
       </td>
           </tr>
           </form>

     
  
    
      
        
                
                <?php
            }
    
?>
     </table>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
<?php

$result = $user->get_all_car($username);
while ($row = $result ->fetch_assoc()){
?>
<script>

$(document).ready(function(){
        $('.plus<?php echo $row['id']?>').click(function (e) {
            e.preventDefault();
             
            var qty = $(this).closest('.product_cart').find('.qty<?php echo $row['id']?>').val();
             console.log(qty);
            var value = parseInt(qty, 10);
            value= isNaN(value) ? 0 : value;
            if(value > 0)
            {
                value++;
                $(this).closest('.product_cart').find('.qty<?php echo $row['id']?>').val(value);
            }
        })

      
    });
    $(document).ready(function(){
        $('.minus<?php echo $row['id']?>').click(function (e) {
            e.preventDefault();
             
            var qty = $(this).closest('.product_cart').find('.qty<?php echo $row['id']?>').val();
             console.log(qty);
            var value = parseInt(qty, 10);
            value= isNaN(value) ? 0 : value;
            if(value > 1)
            {
                value--;
                $(this).closest('.product_cart').find('.qty<?php echo $row['id']?>').val(value);
            }
        });

      
    });
</script>
<?php 
}


$result = $user->get_all_car($username);
while ($row = $result ->fetch_assoc()){
  
?>

           </div>
           

      
           <div class="cart-info-price">
          <div class="bg">
        

            <div class="Details">
                <h4>Total Items</h4>
                <h4><?php $sql = "SELECT COUNT(name) AS total FROM cart WHERE user='$username'";

$result = mysqli_query($conn, $sql);

$data = mysqli_fetch_assoc($result);

echo $data['total']?></h4>

            </div>
            
            <div class="Details">
                <h4>Total Amount</h4>
                <h4>$<?php echo $row['price']*$row['qty']?></h4>

            </div>
            <div class="Details">
           <a href="oder.php">     <button  class="btn">checkout</button></a>
            </div>
          </div>
           </div>
          
          
     
<?php
        }
/*
        $total = 0;
        if (isset($_SESSION['cart'])){
            $product_id = array_column($_SESSION['cart'], 'food_id');
    
            $result = $user->get_all_products();
            while ($row = mysqli_fetch_assoc($result)){
                foreach ($product_id as $id){
                    if ($row['id'] == $id){
                        cartElement(base64_encode($row['img1']), $row['name'], $row['price'], $row['id']);
                       
                        $total = $total + (int)$row['price'];
                    }
                }
            }
        }else{
            echo "<h5>Cart is Empty</h5>";
        }
    

?>

<div class="col-md-4 offset-md-1 border rounded mt-5 bg-white h-25">

<div class="pt-12">
    <h6>PRICE DETAILS</h6>
    <hr>
    <div class="row price-details" style="width:20rem;">
        <div class="col-md-12">
            <?php
                if (isset($_SESSION['cart'])){
                    $count  = count($_SESSION['cart']);
                    echo "<h6>Price ($count items)</h6>";
                }else{
                    echo "<h6>Price (0 items)</h6>";
                }
            ?>
            <h6>Delivery Charges</h6>
            <hr>
            <h6>Amount Payable</h6>
        </div>
        <div class="col-md-6">
            <h6>$<?php echo $total; ?></h6>
            <h6 class="text-success">FREE</h6>
            <hr>
            <h6>$<?php
                echo $total;
                ?></h6>
        </div>
    </div>
</div>

</div>*/
?>
</section>
<style>
    .Details a{
        width: 100%;
    }
.Details .btn{
    background-color: var(--swich-color);
    color: #fff;
    width: 100%;
    padding: .5rem;
}
.Details .btn:hover{
    background-color: #5A5A5A;
}

/*table product*/
table th{
    font-size: 2rem;
    font-weight: bold;
    color: var(--white-1-);
   
}
.table-product{
    overflow: scroll;
}
.table-product::-webkit-scrollbar{
    display: none;
}
table thead{
    background: var(--swich-color);
}
table  tr {
    border-bottom: 1px solid #dddddd;
}
table tr td{
    font-size: 1.5rem;
    font-weight: bold;
}


table tr:last-of-type {
    border-bottom: 2px solid var(--swich-color);
}
table{
    width: auto;
    margin-top: 1.5rem;
}
table thead{
    width: auto;
}
/*------cart views end here---*/
.price{
    font-size:1.3rem;
}
.price,
.first{
  
    font-size:1.3rem;

}
.name{
    
    font-size:1.3rem;

}


.cart-1{
    margin-top: 7rem;
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(20rem,4fr));
   
    padding: 1rem;
}
.cart-all-items{
    padding: 1rem;
    display: block;
    width: auto;
}

.cart-1 .cart-all-items .cart-men{
    background-color: none;
    margin-top: 1rem;
    padding-bottom: 1rem;
    padding: 1rem;
    width: auto;
    display: flex;
    justify-content:space-between;
}

.cart-1 .cart-info-price .Details{
    display: flex;
    justify-content: space-between;


}
.cart-1 .cart-info-price h3{
    color: var(--swich-color);
    font-size: 2rem;
}
.cart-1 .cart-info-price .bg{
    background-color: var(--white-1-);
    padding: 1rem;
    margin-top: 2rem;
}
.cart-1 .cart-des{
  
      
        width: 20rem;
       
     
    }
    .quantity{
        display: flex;
      
    }
    .cart-1 .qty{
        margin-top: .2rem;
        color: black;
        margin-left:.5rem ;
        width: 2rem;
     
        background-color: var(--white-1-);
    }
    .cart-1 .plus,
    .cart-1 .minus{

        color: #fff;

    }
    .cart-1 .update i{
        font-size: 1.5rem;
        color: var(--swich-color);
        margin-left: .6rem;
    }
    .cart-1 .plus ,
    .cart-1 .minus{
        font-size: 1rem;
        color: #fff;
        background:  var(--swich-color);
        padding: .5rem;
        padding-bottom: 0;
    }
    .cart-1 button{
       background:none;
        width: 2rem;
       outline:none;
    }
    .cart-1 button:hover{
      background:none;
    }
    .cart-1 i{
      font-size:2rem;
        color: red;
    }
    body.active table .cart_td,
    body.active .main-content .cart-1 .qty,
    body.active .main-content .cart-1 span,
    body.active .main-content .cart-1 .cart-info-price .bg h4{
      color:#fff;
    }
    body.active .main-content .cart-1 .qty,
   body.active .main-content .cart-1 .cart-info-price .bg,
   body.active .main-content .cart-1 .cart-all-items table{
        background-color: var(--black-1-);

    }
    

</style>
 
<?php
  }else{
    header('Location: login.php');
	exit();
	}
include_once "php/footer.php";

?>