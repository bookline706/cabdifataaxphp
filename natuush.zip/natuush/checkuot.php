<?php
	session_start();
	require "php/db.php";
	require_once "php/function.php";
  require "php/component.php";
  
	$user = new login_registration_class();
 
if (isset($_POST['add'])){
  print_r($_POST['food_id']);
  if(isset($_SESSION['cart'])){

      $item_array_id = array_column($_SESSION['cart'], "food_id");

      if(in_array($_POST['food_id'], $item_array_id)){
      
      }else{

          $count = count($_SESSION['cart']);
          $item_array = array(
              'food_id' => $_POST['food_id']
          );

          $_SESSION['cart'][$count] = $item_array;
      }
    

  }else{

      $item_array = array(
              'food_id' => $_POST['food_id']
      );

      // Create new session variable
      $_SESSION['cart'][0] = $item_array;
      print_r($_SESSION['cart']);
  }
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.2.19/tailwind.min.css" integrity="sha512-wnea99uKIC3TJF7v4eKk4Y+lMz2Mklv18+r4na2Gn1abDRPPOeef95xTzdwGD9e6zXJBteMIhZ1+68QC5byJZw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@200;300;400;600;700&family=Poppins:wght@300;400;500;600&family=Roboto:wght@100;300;400;500;700&family=Satisfy&display=swap" rel="stylesheet">

  <!----  <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css">-->
    
 
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css">

     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.13.6/css/selectize.bootstrap5.css">
     <link rel="stylesheet" href="glider min/glider.min.css"/>
    <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <link rel="stylesheet" href="style.css">
    <title>Natuush</title>
</head>
<?php
  include "php/header.php";
  include "php/header-top.php";

?>

<section class="oder-prodect" style="margin-top:7rem;">
            <form action="" style=" display: grid;
          grid-template-columns: repeat(auto-fit, minmax(20rem,4fr));
          gap: 3rem;">
            <div class="">
               
                <div class="" >
                  <div class="">
                    <input type="text" class="fullname" placeholder="Your Email" >
                    <input type="text" class="phone" placeholder="Your Phone"><br>
                    <input type="text" class="email" placeholder="Your Full Name"><br>
                    <textarea name="" id="" cols="30" rows="10" placeholder="Your Massege">
                 
                       

                    </textarea>
                    <br><br>
                  <center>  <button class="btn">Oder</button></center>
                </div>
               
            </div>
           
        </div>
        <div class="item-oder">
     
       
           <?php

$total = 0;
    if (isset($_SESSION['cart'])){
        $product_id = array_column($_SESSION['cart'], 'food_id');

        $result = $user->get_all_products();
        while ($row = mysqli_fetch_assoc($result)){
            foreach ($product_id as $id){
                if ($row['id'] == $id){

                    ?>
        <div class="cart-info-price">
          <div class="bg">
            <h3>Price Details</h3>
            <div class="Details">
                <h4>Total Items</h4>
                <?php
                            if (isset($_SESSION['cart'])){
                                $count  = count($_SESSION['cart']);
                                echo "<h4>($count)</h4>";
                            }else{
                                echo "<h4>(0 )</h4>";
                            }
                        ?>
               
            </div>
            <div class="Details">
                <h4>Delivery Change</h4>
                <h4>$40.00</h4>
            </div>
            <div class="Details">
                <h4>Total Amount</h4>
                <h4>$<?php echo $total;?></h4>
            </div>
          </div>
           </div>
          
                    <?php
                    $total = $total + (int)$row['price'];
                }
            }
        }
    }else{
        echo "<h5>Cart is Empty</h5>";
    }

?>

           </div>
          
          
           <?php                   

if (isset($_POST['remove'])){
    if ($_GET['action'] == 'remove'){
        foreach ($_SESSION['cart'] as $key => $value){
            if($value["food_id"] == $_GET['id']){
                unset($_SESSION['cart'][$key]);
              echo "ttt";
            }
        }
    }
  }
  
?>
<?php
/*
$total = 0;
    if (isset($_SESSION['cart'])){
        $product_id = array_column($_SESSION['cart'], 'food_id');

        $result = $user->get_all_products();
        while ($row = mysqli_fetch_assoc($result)){
            foreach ($product_id as $id){
                if ($row['id'] == $id){
                    cartElement($row['img1'], $row['name'], base64_encode($row['price']), $row['id']);
                   
                    $total = $total + (int)$row['price'];
                }
            }
        }
    }else{
        echo "<h5>Cart is Empty</h5>";
    }

?>

<div class="col-md-4 offset-md-1 border rounded mt-5 bg-white h-25">

<div class="pt-12">
    <h6>PRICE DETAILS</h6>
    <hr>
    <div class="row price-details" style="width:20rem;">
        <div class="col-md-12">
            <?php
                if (isset($_SESSION['cart'])){
                    $count  = count($_SESSION['cart']);
                    echo "<h6>Price ($count items)</h6>";
                }else{
                    echo "<h6>Price (0 items)</h6>";
                }
            ?>
            <h6>Delivery Charges</h6>
            <hr>
            <h6>Amount Payable</h6>
        </div>
        <div class="col-md-6">
            <h6>$<?php echo $total; ?></h6>
            <h6 class="text-success">FREE</h6>
            <hr>
            <h6>$<?php
                echo $total;
                ?></h6>
        </div>
    </div>
</div>

</div>*/
?>
</section>
<style>
    


/*------cart views end here---*/



.cart-1{
    margin-top: 7rem;
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(20rem,4fr));
   
    padding: 1rem;
}
.cart-all-items{
    padding: 1rem;
    display: block;
    width: auto;
}

.cart-1 .cart-all-items .cart-menu{
    background-color: #fff;
    margin-top: 1rem;
    padding-bottom: 1rem;
    padding: 1rem;
    width: auto;
}

.cart-1 .cart-info-price .Details{
    display: flex;
    justify-content: space-between;
    margin-top: 1rem;

}
.cart-1 .cart-info-price h3{
    color: var(--swich-color);
    font-size: 2rem;
}
.cart-1 .cart-info-price .bg{
    background-color: var(--white-1-);
    padding: 1rem;
    margin-top: 2rem;
}
.cart-1 .cart-des{
  
      
        width: 20rem;
       
     
    }
    .cart-1 button{
       background:none;
        width: 2rem;
       outline:none;
    }
    .cart-1 button:hover{
      background:none;
    }
    .cart-1 i{
      font-size:2rem;
        color: red;
    }

    .content.active .main-content .cart-1 .cart-info-price .bg h4{
      color:#fff;
    }
   .content.active .main-content .cart-1 .cart-info-price .bg,
    .content.active .main-content .cart-1 .cart-all-items .cart-menu{
        background-color: var(--black-1-);

    }
    .cart-none{
      display:inline-block;

    }

</style>
           
   <script>
      const products = [
    <?php

//$db = new PDO('mysql:host=localhost; dbname=natuush','root','');
$db = mysqli_connect('localhost', 'root', '', 'natuush');
//$result = $conn->query($sql);

    $sql = ('select * from product  order by id DESC');
$result = $db->query($sql);
	
  
   
   while($im = $result->fetch_assoc()){
  ?>
    {
    
      idnumer: 1,
      id: <?php echo $im['id']?>,
      name: "jkhkjlo",
      price: 29.99,
      instock: 100,
      description:
        "<?php echo base64_encode($im['desc']); ?>",
      imgSrc: " data:image/jpg;charset=utf8;base64,<?php echo base64_encode($im['img1']); ?>",
      imgSrc1: " data:image/jpg;charset=utf8;base64,<?php echo base64_encode($im['img2']); ?>",
    
    },
     <?php
}
   


?>
];
const productbtn = [
  <?php
$sql = ('select * from product where bestseler=0');
$result = $db->query($sql);
	
  
   
   while($im = $result->fetch_assoc()){
  ?>
    {
    
      idnumer: 1,
      id: <?php echo $im['id']?>,
      name: "jkhkjlo",
      price: 29.99,
      instock: 100,
      description:
        "<?php echo base64_encode($im['desc']); ?>",
      imgSrc: " data:image/jpg;charset=utf8;base64,<?php echo base64_encode($im['img1']); ?>",
      imgSrc1: " data:image/jpg;charset=utf8;base64,<?php echo base64_encode($im['img2']); ?>",
    
    },
     <?php
}
   


?>
];
</script>
<?php
include_once "php/footer.php";

?>




















