const products = [
    {
      idnumer: 1,
      id: 0,
      name: "T-shirt hgkgl1",
      price: 29.99,
      instock: 100,
      description:
        "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Asperiores, error.",
      imgSrc: "./image/Screenshot 2022-12-10 025552.jpg",
    },
    {
      
    
      idnumer: 1,
        id: 1,
        name: "T-shirt 1",
        price: 29.99,
        instock: 100,
        description:
          "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Asperiores, error.",
        imgSrc: "./image/Screenshot 2022-12-10 025552.jpg",
      },
      {
        idnumer: 1,
        id: 2,
        name: "T-shirt 1",
        price: 29.99,
        instock: 100,
        description:
          "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Asperiores, error.",
        imgSrc: "./image/Screenshot 2022-12-10 025552.jpg",
      },
      {
        idnumer: 1,
        id: 3,
        name: "T-shirt 1",
        price:29.99,
        instock: 100,
        description:
          "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Asperiores, error.",
        imgSrc: "./image/Screenshot 2022-12-10 025552.jpg",
      },
      {
        idnumer: 1,
        id: 4,
        name: "T-shirt 1",
        price: 29.99,
        instock: 100,
        description:
          "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Asperiores, error.",
        imgSrc: "./image/Screenshot 2022-12-10 025552.jpg",
      },
      {
        idnumer: 1,
        id: 5,
        name: "T-shirt 1",
        price: 29.99,
        instock: 100,
        description:
          "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Asperiores, error.",
        imgSrc: "./image/Screenshot 2022-12-10 025552.jpg",
      }
    
];


const prodcutView =[

  {
    idnumer: 1,
    id: 1,
    name: "T-shirt gjgg",
    price: 29.99,
    instock: 100,
    description:
      "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Asperiores, error.",
    imgSrc: "./image/bg.jpg",
    imgSrc1: "./image/Screenshot 2022-12-10 025552.jpg",
    imgSrc2: "./image/Screenshot 2022-12-10 025552.jpg",
    imgSrc3: "./image/Screenshot 2022-12-10 025552.jpg",
    imgSrc4: "./image/Screenshot 2022-12-10 025552.jpg",
  }
];

const CartCleer =
[
  {
  idnumer: 1,
  name: "Your Cart"
  }
]


const Oder =
[
  {
  idnumer: 1,
  name: "Oder"
  }
]













