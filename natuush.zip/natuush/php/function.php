<?php
class login_registration_class{
	public function __construct(){
		$conn = new databaseConnection();
	}
//$db = new PDO('mysql:host=localhost; dbname=natuush','root','');

  
public function show_product_owner($id){
    global $conn;
    $result = $conn->query("select * from product where id='$id'");
    $count = $result->num_rows;
    if($count>0){
        return $result;
    }else{
        return false;
    }
    
}
  
public function show_catygory($catygory){
    global $conn;
    $resul =  $conn->query("select * from product where catygory='$catygory'");
    $count = $resul->num_rows;
    if($count>0){
        return $resul;
    }else{
        return false;
    }
    
}
public function show_cart($name, $price, $qty, $usern){
    global $conn;
    $resul =  $conn->query("select * from cart where name='$name' and user='$usern'");
    $nun = $resul->num_rows;
    $sql = "INSERT INTO cart(name,price,qty,user) VALUES ('$name','$price','$qty','$usern')"; 

    if($nun == 0){
        $conn->query($sql);
        return true;
    }else{
        return false;
    }
    
}
public function show_heart($name, $price,  $usern){
    global $conn;
    $resul =  $conn->query("select * from heart where name='$name' and user='$usern'");
    $nun = $resul->num_rows;
    $sql = "INSERT INTO heart(name,price,user) VALUES ('$name','$price','$usern')"; 

    if($nun == 0){
        $conn->query($sql);
        return true;
    }else{
        return false;
    }
    
}
public function show_register($name, $email, $phone,  $username, $password){
    global $conn;
  
    $sql = "INSERT INTO login(name,email,phone,username,password) VALUES ('$name','$email','$phone','$username','$password')"; 

  
        $conn->query($sql);
        return true;
 
    }
    

public function show_contact($name, $phone,  $email, $massage){
    global $conn;
    $sql=  "INSERT INTO `contact`(`name`, `phone`, `email`, `massege`) VALUES('$name','$phone','$email','$massage')";
    if($sql){
        $conn->query($sql);
        return true;
    }else{
        return false;
    }
    
}

public function getgaleryid(){
    global $conn;
    $sql = "select * from galery  order by id DESC";
    $query = $conn->query($sql);
    return $query;
}

public function getproductid(){
    global $conn;
    $query = $conn->query("select * from product where bestseler='yes'");
    return $query;
}
public function get_all_products(){
    global $conn;
    $sql = "select * from product order by id DESC";
    $query = $conn->query($sql);
    return $query;
}
public function get_all_about(){
    global $conn;
    $sql = "select * from about order by id DESC";
    $query = $conn->query($sql);
    return $query;
}
public function get_all_cart($user){
    global $conn;
    $sql = "select * from cart where user='$user'";
    $query = $conn->query($sql);
    return $query;
}
public function get_all_car($username){
    global $conn;
    $sql = "SELECT * FROM cart WHERE user='$username'";
    $query = $conn->query($sql);
    return $query;
}
public function get_all_heart($username){
    global $conn;
    $sql = "SELECT * FROM heart WHERE user='$username'";
    $query = $conn->query($sql);
    return $query;
}
public function get_all_login($username){
    global $conn;
    $sql = "select * from login where username='$username'";
    $query = $conn->query($sql);
    return $query;
}

public function get_all_galers(){
    global $conn;
    $sql = "select * from galery order by id DESC";
    $query = $conn->query($sql);
    return $query;
}

public function get_all_social(){
    global $conn;
    $sql = "select * from social order by id DESC";
    $query = $conn->query($sql);
    return $query;
}

public function get_all_numbers(){
    global $conn;
    $sql = "select * from numbers order by id DESC";
    $query = $conn->query($sql);
    return $query;
}
public function get_all_catygory(){
    global $conn;
    $sql = "select * from catygory order by catygory DESC";
    $query = $conn->query($sql);
    return $query;
}

public function searchproduct($query){
   global $conn;
   $resul = $conn->query("SELECT * FROM product WhERE (name LIKE '%".$query."%'
                                OR name LIKE '%".$query."%' ) order by id");
   return $resul;
}

}


?>