<?php
		$conn = mysqli_connect("localhost", "root", "" , "natuush");

        if(isset($_POST["insert"]))  
        {  
            $name = $_POST['name'];
            $price= $_POST['price'];
            $qty=1;
             $file = addslashes(file_get_contents($_FILES["image"]["tmp_name"]));  
             $query = "INSERT INTO cart(name,price,qty,image) VALUES ('$name','$price','$qty','$file')";  
             if(mysqli_query($conn, $query))  
             {  
                  echo '<script>alert("Image Inserted into Database")</script>';  
             }  
        }  

        
    $sql = ('select * from cart  order by id DESC');
    $result = $conn->query($sql);
        
      
       
       while($im = $result->fetch_assoc()){
        ?>

<img class="items" src="<?php echo $im['image']?>"  />  
        <?php
       }
        ?>  
         <form method="post" enctype="multipart/form-data">   
                             <input type="text" name="name" id="">
                             <input type="text" name="price" id="">

                             <input type="file" name="image" id="image" />  
                             <br />  
                             <input type="submit" name="insert" id="insert" value="Insert" class="btn btn-info" />  
                        </form>  
          
         <script>  
         $(document).ready(function(){  
              $('#insert').click(function(){  
                   var image_name = $('#image').val();  
                   if(image_name == '')  
                   {  
                        alert("Please Select Image");  
                        return false;  
                   }  
                   else  
                   {  
                        var extension = $('#image').val().split('.').pop().toLowerCase();  
                        if(jQuery.inArray(extension, ['gif','png','jpg','jpeg']) == -1)  
                        {  
                             alert('Invalid Image File');  
                             $('#image').val('');  
                             return false;  
                        }  
                   }  
              });  
         });  
         </script>  


