<?php
  if (isset($_SESSION['id']) && isset($_SESSION['user'])) {
  $username = $_SESSION['user'];
  
  if(isset($_POST["add"]))  
  {  
      $name = $_POST['name'];
      $price= $_POST['price'];
      $qty=1;
      $usern = $_POST['username'];
     
      if(empty($name))
      {

    
       echo '<script>alert("filed")</script>';  
       
      }
      else{

       $cart= $user->show_cart($name,$price,$qty,$usern);
   
       if($cart){
       echo '<script>alert("Product Is Added Your Cart")</script>'; 
       header("Location: index.php");
       exit();
  
      }else{
      ?>
      <h3>This Product is Already into Your Cart</h3>
      <?php
       header("Location: index.php");
       exit();

      }
  }  }
?>


             <div class="main-content ">
               <div class="header-top">
                  <div class="card-header hed">
      
      <i class="fas fa-bars menu-1"></i>
           <i class="fas fa-bars menu"></i>
           <i class="fas fa-user open-profile"></i>
        

      <a href="cart.php?user=<?php echo $username?>">  <i class="fa-solid fa-cart-shopping opencart"><span class="total-items-in-cart"><?php $sql = "SELECT COUNT(name) AS total FROM cart WHERE user='$username'";

$result = mysqli_query($conn, $sql);

$data = mysqli_fetch_assoc($result);

echo $data['total']?></span></i>
         </a>
  
         <i class="fas fa-heart openhearts"><span><?php $sql = "SELECT COUNT(name) AS total FROM heart WHERE user='$username'";

$result = mysqli_query($conn, $sql);

$data = mysqli_fetch_assoc($result);

echo $data['total']?></span></i>
           <i name="close-outline" style="display:none;" class="fas fa-sun close"></i>
          <i name="open-outline"  style="display:none;" class="fas fa-moon toggleButton"></i>
           <i id="theme-toggle"class="fas fa-moon moon"></i>
           <i id="theme-toggl"class="fas fa-sun sun"> </i>

         </div>
  <form action="search_product.php" method="get">
      
     <div class="search">
      
      <div class="serch">
      


  
      <div class="dropdown">
<button class="dropbtn">Catygory</button>
<div class="dropdown-content">
<?php 

$result = $user->get_all_catygory();
while($row = $result->fetch_assoc())
{
catygory($row['catygory']);
?>

<?php } ?>
</div>
</div>


          <input type="text" name="search" placeholder="Search for names.." title="Type in a name" id="serchproduct" class="form-control">
          <button type="submit" name="submit" >Search</button>
      </div>
     </div>
</div>

  </form>




<section class="hearts">
  <form action="" method="post">
     <div class="close-cart">
      <i class="fas fa-close closeheart"></i>
     </div>
      <div class="cart-all">
          <div class="cart-header">
            
       
              
          </div>
          <table class="table">
    
    <thead>
        <th>Name</th>
        <th>Price</th>
        <th>Add</th>
         <th>Delete</th>
    </thead>
 
    <?php
   
        
    if(isset($_POST['deleteheart'])){
        $name= $_POST['name'];
        $price = $_POST['price'];
        $id = $_POST['id'];
        $sql = "DELETE FROM `heart` WHERE id='$id' and user='$username'";
        
       
        if($conn->query($sql) === TRUE) {
            ?>
          <span style=" background-color: rgb(179, 116, 130); color:#fff; border-radius: .5rem; width: 100%; padding: .5rem;">Item is Deleted</span>
            <?php
        }
    }

$result = $user->get_all_heart($username);
        while ($row = $result ->fetch_assoc()){
       ?>
        <form action="" method="post" class="cart-items">
            <input type="hidden" name="id" value="<?php echo $row['id']?>">
            <input type="hidden" name="name" value="<?php echo $row['name']?>">
            <input type="hidden" name="price" value="<?php echo $row['price']?>">
            <input type="hidden" name="username" value="<?php echo $_SESSION['user']?>">
            
            
       <tr>
        <td>  <div class="name">
    <span><?php echo $row['name']?></span>
   </div></td>
   <td>
   <div class="price">
    <span>$<?php echo $row['price']?></span>
</div>
   </td>
  <td>
    <button type="submit" name="add"><i class="fas fa-shopping-cart" style="color:green;"></i></button>
  </td>
   <td>
   <div class="acti">

  <button type="submit" name="deleteheart">
    <i style="color:red;" class="fas fa-close cart_remove"></i>
    </button>

  </div>
   </td>
       </tr>
       </form>

 


  
    
            
            <?php
        }

?>
 </table>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>

      
 


<style>
  .sun{
    display:none;

  }
  .moon{
    display:inline-block;
  }
  body.active .sun{
    display: inline-block;
  }
  body.active .moon{
    display:none;
  }
.Details a{
    width: 100%;
}
.Details .btn{
background-color: var(--swich-color);
color: #fff;
width: 100%;
padding: .5rem;
}
.Details .btn:hover{
background-color: #5A5A5A;
}

/*table product*/
table th{
font-size: 2rem;
font-weight: bold;
color: var(--white-1-);

}
.table-product{
overflow: scroll;
}
.table-product::-webkit-scrollbar{
display: none;
}
table thead{
background: var(--swich-color);
}
table  tr {
border-bottom: 1px solid #dddddd;
}
table tr td{
font-size: 1.5rem;
font-weight: bold;
}


table tr:last-of-type {
border-bottom: 2px solid var(--swich-color);
}
table{
width: auto;
margin-top: 1.5rem;
}
table thead{
width: auto;
}
/*------cart views end here---*/
.price{
font-size:1.3rem;
}
.price,
.first{

font-size:1.3rem;

}
.name{

font-size:1.3rem;

}


.cart-1{
margin-top: 7rem;
display: grid;
grid-template-columns: repeat(auto-fit, minmax(20rem,4fr));

padding: 1rem;
}
.cart-all-items{
padding: 1rem;
display: block;
width: auto;
}

.cart-1 .cart-all-items .cart-men{
background-color: none;
margin-top: 1rem;
padding-bottom: 1rem;
padding: 1rem;
width: auto;
display: flex;
justify-content:space-between;
}

.cart-1 .cart-info-price .Details{
display: flex;
justify-content: space-between;


}
.cart-1 .cart-info-price h3{
color: var(--swich-color);
font-size: 2rem;
}
.cart-1 .cart-info-price .bg{
background-color: var(--white-1-);
padding: 1rem;
margin-top: 2rem;
}
.cart-1 .cart-des{

  
    width: 20rem;
   
 
}
.quantity{
    display: flex;
  
}
.cart-1 .qty{
    margin-top: .2rem;
    color: black;
    margin-left:.5rem ;
    width: 2rem;
 
    background-color: var(--white-1-);
}
.cart-1 .plus,
.cart-1 .minus{

    color: #fff;

}
.cart-1 .update i{
    font-size: 1.5rem;
    color: var(--swich-color);
    margin-left: .6rem;
}
.cart-1 .plus ,
.cart-1 .minus{
    font-size: 1rem;
    color: #fff;
    background:  var(--swich-color);
    padding: .5rem;
    padding-bottom: 0;
}
.cart-1 button{
   background:none;
    width: 2rem;
   outline:none;
}
.cart-1 button:hover{
  background:none;
}
.cart-1 i{
  font-size:2rem;
    color: red;
}
body.active table td,
body.active .main-content .cart-1 .qty,
body.active .main-content .cart-1 span,
body.active .main-content .cart-1 .cart-info-price .bg h4{
  color:#fff;
}
body.active .main-content .cart-1 .qty,
body.active .main-content .cart-1 .cart-info-price .bg,
body.active .main-content .cart-1 .cart-all-items table{
    background-color: var(--black-1-);

}


</style>

                
                   <!-----0637878502------->
                    

          </div>
          
          <div class="block her">
             
             
          <div class="">
             
              
              
              
          </div>
         
      
      </div>
      
  </form>
</section>







<!-- start Profile---->

<section class="profile">
<div class="close-profile">
<a href="loguot.php"><i class="fa-sharp fa-solid fa-left-long"><span>Logout</span></i></a>
<i class="fas fa-close closeprofile"></i>
</div>
<div class="profile-face">
<center><img src="image/bg.jpg" alt=""></center>
</div>


<div class="profileInfo">
<div class="top">
<h1>Welcome </h1> <h2><?php echo $_SESSION['user']?></h2>
</div>
<div class="center" >


</div>

</div>
</section>


<!-- end Profile---->



<?php
}else{
  ?>
  



<div class="main-content ">
          <div class="header-top">
          <div class="card-header hed">
                
                <i class="fas fa-bars menu-1"></i>
                     <i class="fas fa-bars menu"></i>
                     <i class="fas fa-user open-profile"></i>
                    
                <a href="cart.php">  <i class="fa-solid fa-cart-shopping opencart"><span class="total-items-in-cart">0</span></i>
                   </a>
            
                   <i class="fas fa-heart openhearts"><span>0</span></i>
                     <i name="close-outline" style="display:none;" class="fas fa-sun close"></i>
                    <i name="open-outline"  style="display:none;" class="fas fa-moon toggleButton"></i>
                    <i id="theme-toggle"class="fas fa-moon moon"></i>
           <i id="theme-toggl"class="fas fa-sun sun"> </i>
            
                   </div>
            <form action="search_product.php" method="get">
                
               <div class="search">
                
                <div class="serch">
                


            
                <div class="dropdown">
  <button class="dropbtn">Catygory</button>
  <div class="dropdown-content">
    <?php 
    	
    $result = $user->get_all_catygory();
    while($row = $result->fetch_assoc())
    {
        catygory($row['catygory']);
    ?>
  
  <?php } ?>
  </div>
</div>


                    <input type="text" name="search" placeholder="Search for names.." title="Type in a name" id="serchproduct" class="form-control">
                    <button type="submit" name="submit" >Search</button>
                </div>
               </div>
          </div>
          
            </form>
       
        
        
    
        <section class="hearts">
            <form action="" method="post">
               <div class="close-cart">
                <i class="fas fa-close closeheart"></i>
               </div>
                <div class="cart-all">
                    <div class="cart-header">
                      
                 
                        </script>
                    </div>
                    <div class="  content-heart">
 
                      
                          
                             <!-----0637878502------->
                              

                    </div>
                    
                    <div class="block her">
                       
                       
                    <div class="cart-total">
                        <div class="total-price">
                            <span class="totals">Total Price:</span> <span class="price total">$0</span>
                        </div>
                       
                        
                        
                        
                    </div>
                   
                
                </div>
                
            </form>
        </section>







<!-- start Profile---->


<section class="profile">
    <div class="close-profile">
      <a href="loguot.php"> <i class="fa-sharp fa-solid fa-left-long"><span>Logout</span></i>
    </a>
        <i class="fas fa-close closeprofile"></i>
    </div>
<div class="profile-face">
    <center><img src="image/bg.jpg" alt=""></center>
</div>

<style>
  s{
    pa
  }
</style>
<div class="profileInfo">
  <div class="top">
   <a href="register.php" style="background: blue; color:#fff;padding:.5rem;">Register</a>/ <a href="login.php" style="background: green; color:#fff;padding:.5rem;">Login</a>
  </div>
  <div class="center" >
    <a href="loguot.php"><i class="fa-sharp fa-solid fa-right-long"></i><span>Your Oder</span></a><br><br>
   <a href="Edit-profile-c.html"><i class="fa-sharp fa-solid fa-right-long"></i><span>Change Your Profile</span></a>

  </div>
  
</div>
    </section>

<!-- end Profile---->



<?php
}

?>