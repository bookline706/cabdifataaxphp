

       <section class="footer">
      
      <div class="content">
          <div class="top-2">
              <ul class="catigory catigory-1">
                  <h3>Natuush</h3>
                  <p>Taxonomy is the science of naming, 
                      describing and classifying organisms 
                      and includes all plants, animals and 
                      microorganisms of the world</p>
                      <li class="social">
                          <i class="fa-brands fa-facebook-f"></i>      
                          <i class="fa-brands fa-whatsapp"></i>
                          <i class="fa-brands fa-instagram"></i>                  </li>
                  </ul>
              <ul class="catigory">
                  <h3>Catygory</h3>
                   <?php 

$result = $user->get_all_catygory();
while($row = $result->fetch_assoc())
{
catygory($row['catygory']);
?>

<?php } ?>
                   
              </ul>
              <ul class="catigory">
                  <h3>Headers</h3>
                  <li>Home</li>
                  <li>ABOUT</li>
                  <li>Foods</li>
                  <li>Best Oder</li>
                  <li>Contact Us</li>
             </ul>
             <ul class="catigory">
     

              <h3>Acounts</h3>
              <li>Profile</li>
              <li>Cart</li>
              <li>Oder</li>
              <li>Chickout</li>
         </ul>
          </div>
          
      </div>
      <div class="bottom">
          <span><h3>Copyright:</h3><a href="https://www.natuush.com/">natuush.com</a></span>
      </div>
    
        
     </section>
    </body>
    </html>
    
     <div class="nav-2">
      <ul class="nav-1 ">
          <li><a href="#home" class=" menuclose"><i class="fa fa-home menuclose"></i></a></li>
          <li><a href="#food"  class=" menuclose"><i class="fas fa-bread-slice	"></i></a></li>
          <li><a href="#about"  class=" menuclose"><i class="fa-solid fa-info"></i></a></li>
        
          <li><a href="#contact"  class=" menuclose"><i class="fa-solid fa-comment"></i></a></li>
      </ul>
     </div>
      <div class="theme-buttons-container-1 colors">
          <div class="top">
              <i class="fas fa-close menuclose-1"></i>
          </div>
          <span class="color" data-color="rgb(0, 126, 164)" style="background:rgb(0, 126, 164);"></span>
          <span class="color" data-color="rgb(219, 140, 36)"style="background:rgb(219, 140, 36);"></span><br>
          <span class="color" data-color="rgb(218, 35, 235)" style="background:rgb(218, 35, 235);"></span>
          <span class="color" data-color="rgb(52, 29, 255)" style="background:rgb(52, 29, 255);"></span><br>
          <span class="color" data-color="rgb(12, 129, 1)" style="background:rgb(12, 129, 1);"></span>
          <span class="color" data-color="rgb(156, 108, 175)" style="background:rgb(156, 108, 175);"></span><br>
          <span class="color" data-color="rgb(8, 119, 122)" style="background:rgb(8, 119, 122);"></span>
          <span class="color" data-color="rgb(255, 0, 0)" style="background:rgb(255, 0, 0);"></span>
         
         
      </div>
      </div>
     
      <!------------end content----------->


      
  </div>
  <script>
    
    let maincolor = localStorage.getItem("color_swich");
if (maincolor !== null){
  //  console.log('Local store is not empty ');  
    //cosole.log(localStorage.getItem("color_swich"));
    document.documentElement.style.setProperty('--swich-color', localStorage.getItem("color_swich"));
}




    let colorList = document.querySelectorAll('.theme-buttons-container-1 span');
    console.log(colorList);
    colorList.forEach(span =>{

      span.addEventListener("click", (e) => {
document.documentElement.style.setProperty('--swich-color', e.target.dataset.color);

        localStorage.setItem("color_swich", e.target.dataset.color);
      });

    });

    let colorss = localStorage.getItem("color");
if (colorss !== null){
  //  console.log('Local store is not empty ');  
    //cosole.log(localStorage.getItem("color"));
    document.documentElement.style.setProperty('--swich-color', localStorage.getItem("color"));
}




    let colorlis = document.querySelectorAll('.theme-buttons-container span');
    console.log(colorlis);
    colorlis.forEach(span =>{

      span.addEventListener("click", (e) => {
document.documentElement.style.setProperty('--swich-color', e.target.dataset.color);

        localStorage.setItem("color", e.target.dataset.color);
      });

    });

  </script>
 
 <script>
   /*   const products = [










 </script>
 <style>
  .dark-theme {
  --bg-color: #171923;
    --bg-light: #232535;
    --font-color: #c5cddb;
    --font-light: #ffffff;
}
/* end switch color theme */
.nav-links #toggle {
  pointer: cursor !important;
}
* {
   box-sizing: border-box;
   margin: 0;
   padding: 0;
}
body {
    color: var(--font-light);
    font-family: 'Montserrat', sans-serif;
    background-color: var(--bg-color);
    transition: all 500ms;
}
 </style>
 

<script>
  
let toggleButton = document.querySelector('.toggleButton');
let close = document.querySelector('.close');
let content = document.querySelector('.content');
let menu = document.querySelector('.menu');
let asside = document.querySelector('.asside');
let menuclos = document.querySelector('.menuclos');
let nem = document.querySelector(".nam");
let heart = document.querySelector(".openhearts");
let closeheart = document.querySelector(".closeheart");
let openprofile = document.querySelector(".open-profile");
let closeprofile = document.querySelector(".closeprofile");

openprofile.onclick = function () {
  content.classList.add('opened-profile');

}
closeprofile.onclick = function () {
  content.classList.remove('opened-profile');
}


heart.onclick = function () {
  content.classList.add('active-heart');

}
closeheart.onclick = function () {
  content.classList.remove('active-heart');
}

toggleButton.onclick = function () {
    content.classList.add('active');

}
close.onclick = function () {
    content.classList.remove('active');
}

menu.onclick = function () {
    content.classList.add('action');

}
menuclos.onclick = function () {
    content.classList.remove('action');
}
 

let menu_1 = document.querySelector('.menu-1');
let color = document.querySelector('.colors');

let menuclose_1 = document.querySelector('.menuclose-1');



menu_1.onclick = function () {
    color.classList.add('active-1');

}
menuclose_1.onclick = function () {
    color.classList.remove('active-1');
}
// swich colors


    /// cart
 let cart_2 = document.querySelector('.cart_2');
 let openecart = document.querySelector('.opencart');
let closecart = document.querySelector('.closecart');



openecart.onclick = function () {
    cart_2.classList.add('active-cart');

}
closecart.onclick = function () {
    cart_2.classList.remove('active-cart');
}


</script>
<script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
 <script src="script.js"></script>
<script>
   const themeToggle = document.querySelector("#theme-toggle");
   const themeToggl = document.querySelector("#theme-toggl");

const currentTheme = localStorage.getItem("theme");
var pageTheme = document.body;

let isDark = true

if (currentTheme == "dark") {
  pageTheme.classList.add("active");

} else {

}

function themeMode() {
    isDark = !isDark;
    isDark ? themeToggle.innerText = "" : themeToggle.innerText = "";
    pageTheme.classList.toggle("active");

    let theme = "light";
    if (pageTheme.classList.contains("active")) {
      theme = "dark";
    }
    localStorage.setItem("theme", theme);
}

themeToggle.addEventListener("click", themeMode);
themeToggl.addEventListener("click", themeMode)
</script>


</body>
</html>