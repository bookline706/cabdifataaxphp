

    <div class="main-contaner content asside cart_2 "  id="wrapper"> 
        <!-------------start asside---------->
       
        <div class="main-asside ">
            <div class="icon">
                <i class="fas fa-close menuclos"></i>
            </div>
            <center><div class="logo">
                <h3>Natuush</h3>
            </div></center>
       
            <ul class="nav">
                <li><a href="index.php#home" class=" menuclose"><i class="fa fa-home menuclose"></i>Home</a></li>
                <li><a href="index.php#food"  class=" menuclose"><i class="fas fa-bread-slice	"></i>Foods</a></li>
                <li><a href="index.php#about"  class=" menuclose"><i class="fa-solid fa-info"></i>About</a></li>
                <li><a href="index.php#Galery"  class=" menuclose"><i class="fas fa-image"></i>Galeries</a></li>
                <li><a href="index.php#contact"  class=" menuclose"><i class="fa-solid fa-comment"></i>Contact</a></li>
            </ul>

            <div class="theme-buttons-container ">
            <span class="color" data-color="rgb(0, 126, 164)" style="background:rgb(0, 126, 164);"></span>
          <span class="color" data-color="rgb(219, 140, 36)"style="background:rgb(219, 140, 36);"></span>
          <span class="color" data-color="rgb(218, 35, 235)" style="background:rgb(218, 35, 235);"></span>
          <span class="color" data-color="rgb(52, 29, 255)" style="background:rgb(52, 29, 255);"></span>
          <span class="color" data-color="rgb(12, 129, 1)" style="background:rgb(12, 129, 1);"></span>
          <span class="color" data-color="rgb(156, 108, 175)" style="background:rgb(156, 108, 175);"></span>
          <span class="color" data-color="rgb(8, 119, 122)" style="background:rgb(8, 119, 122);"></span>
          <span class="color" data-color="rgb(255, 0, 0)" style="background:rgb(255, 0, 0);"></span>
        

               
            </div>
            <div class="shawakh">
                 <a href="https://www.shawakhtechnology.com/">Shawakhtechnology.com</a>
            </div>
        </div>
        <!-------------end asside---------->



   