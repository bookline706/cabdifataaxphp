<?php

function component($productname, $productprice, $productimg,$productimg1, $productid){
    $element = "

<div class=\"row row-222 item\" style=\"width:12rem;\">
<div class=\"row-1\" style=\"padding-top: 1rem;\">
<form action=\"register.php\" method=\"post\" enctype=\"multipart/form-data\"> 
    <a href=\"productv.php?id=$productid\" > <img class=\"image-item ac\" src=\"data:image/jpg;base64,$productimg\" alt=\"Image1\" class=\"img-fluid card-img-top\"></a>

    <a href=\"productv.php?id=$productid\" > <img class=\"image-item none\" src=\"data:image/jpg;base64,$productimg1\" alt=\"Image1\" class=\"img-fluid card-img-top\"></a>
        <div class=\"food_icon\">
           
           
            <a href=\"productv.php?id=$productid\" >  <i class=\"fas fa-eye\"></i> </a>
            <a href=\"register.php\" >   <i class=\"fas fa-heart\"></i> </a>
            
        </div>
    
</div>
<div class=\"footer_food\">
<div class=\"item-name\">
<h4 class=\"title-item\">$productname</h4>
</div>

<div class=\"price-items\">
<h2 class=\"price\"> Price:</h2>
<h2 class=\"price-item\">$$productprice</h2>
</div>
</div>

<input type=\"hidden\" name=\"name\" id=\"\" value=\"$productname\">
<input type=\"hidden\" name=\"price\" id=\"\" value=\"$productprice\">
<button type=\"submit\" class=\"btn btn-warning my-2\" style=\"margin:.7rem ; width:10rem; margin-right:1rem;\" name=\"rr\">Add to Cart <i class=\"fas fa-shopping-cart\"></i></button>
<input type=\"hidden\" name=\"food_id\" value=\"$productid\">
</div> </form>
";
    echo $element;
}

















function catygory($catygory){
    $element = "
    <a href=\"catygory.php?catygory=$catygory\">$catygory</a>
    ";
    echo $element;
}
function heade($user){
     $element = "
    <div class=\"card-header hed\">
                
    <i class=\"fas fa-bars menu-1\"></i>
         <i class=\"fas fa-bars menu\"></i>
         <i class=\"fas fa-user open-profile\"></i>
        
    <a href=\"cart.php?user=$user\">  <i class=\"fa-solid fa-cart-shopping opencart\"><span class=\"total-items-in-cart\">0</span></i>
       </a>

       <i class=\"fas fa-heart openhearts\"><span>0</span></i>
         <i name=\"close-outline\" style=\"display:none;\" class=\"fas fa-sun close\"></i>
        <i name=\"open-outline\"  style=\"display:none;\" class=\"fas fa-moon toggleButton\"></i>
         <button type=\"submit\" id=\"theme-toggle\" style=\"background:none;  margin-top:-.2rem; font-size:1.5rem; boder:none; outline:none\"></button>

       </div>
       ";
       echo $element;
}






function cartElement($productimg, $productname, $productprice, $productid){
    $element ="
    
    <form action=\"cart.php?action=remove&id=$productid\" method=\"post\" class=\"cart-items\">
    <div class=\"cart-menu action product_cart\">
    <div class=\"cart-img\"> 
    <img src=\"data:image/jpg;base64,$productimg\" alt=\"Image1\" class=\"img-fluid card-img-top\">
      </div> <div class=\"cart-des\">
        <div class=\"cart-name\">
            <span>$productname </span>
              </div>  <div class=\"cart-price\">  
                <span class=\"price\">price:</span>
                <span class=\"first\">$$productprice</span>  
                <div class=\"qty cart-none\"><span class=\"btn mines button\"><span>-</span></span><span class=\"quantity\">	<input type=\"text\" id=\"quantity\" name=\"quantity\" class=\"quantity\" value=\"1\" style=\"width: 50px; text-align: center;\" readonly></input>
                </span>
                <input type=\"hidden\" name=\"name\" value=\"$productname\">
                <input type=\"hidden\" name=\"prce\" value=\"$productprice\">
        
       <span class=\"btn plus button\" ><span>+</span></span></div>  </div> 
        </div> 
        <button type=\"submit\" class=\"btn btn-danger mx-2 cart-none \" name=\"remove\">
        <i class=\"fas fa-trash cart_remove\"></i>
        </button>
       
        </div>

                </form>
    
    ";
    echo  $element;
}

















