<?php
	$conn = mysqli_connect("localhost", "root", "" , "natuush");
               if(isset($_GET['id'])){
                $id = $_GET['id'];
                $delete = mysqli_query($conn, " DELETE FROM `cart` WHERE `id`$id'");
                if($delete){
                    echo "deleted";
                }
  }             
?>            