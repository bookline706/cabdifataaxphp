<!DOCTYPE html>
<!-- saved from url=(0064)file:///C:/Users/MQT/Desktop/my%20web%20design/index.html#review -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
    <link rel="stylesheet" href="Albaik/logo.jpg">
	<title>Albik Restuarant website design tutorial</title>
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
    <link rel="stylesheet" href="Albik.css">
   <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/fontawesome.min.css">
   <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@200;300;400;600;700&family=Poppins:wght@300;400;500;600&family=Roboto:wght@100;300;400;500;700&family=Satisfy&display=swap" rel="stylesheet"> 
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css">
   <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css">
  

<body>
	<header class="header">
        <a href="#" class="logo"><i class="fas fa-utensils"></i><span class="aaa">Albaik_</span><span class="hhh">Hargaisa</span></a>
		<nav class="navbar">
         <a  href="#home">Home</a>
         <a href="#dishes">Dishes</a>
         <a  href="#about">About</a>  
        
        </nav>
        
        <div class="icons">
            <i class="fa fa-bars" id="menu-bars"></i>
           <!--- <i id="search-icon" class="fas fa-search"></i>
            <a href="#" class="fas fa-shopping-cart"></a>
            <a href="#" class="fas fa-heart"></a>--> 
            </div>


</header>

<!-----header section ends----------->
<!---------star form---------->
<form action="" id="search-form">
    <input type="search" placeholder="search here..." name="" id="search-box">
   <!--<label for="search-box" class="fas fa-search"></label>--> 
  <i class="fas fa-times" id="close"></i>
</form>
<!--------start section home id-------------->

<section class="home" id="home">

    <div class="swiper mySwiper home-slider">
    
        <div class="swiper-wrapper wrapp">
    
           <div class="swiper-slide slide">
               <div class="content">
               <span class="span">our special dish</span>
             
                  
           </div>
        
           <div class="image">
            <img src="Albaik/menu.jpeg" alt="">
           </div>
    
        </div>
        <div class="swiper-slide slide">
            <div class="content">
            <span class="span">our special dish</span>
               
        </div>
    
        <div class="image">
          <img src="Albaik/menu2.jpeg" alt="">
        </div>
    
     </div>
     <div class="swiper-slide slide">
        <div class="content">
        <span class="span">our special dish</span>
       
           
    </div>
    
    <div class="image" id="ss">
        <img src="Albaik/menu3.jpeg" alt="">
    </div>
    
    </div>
    
    </div>
    
    
    
    </div>
       
         </div>
         <div class="swiper-pagination"></div>
    
    </div>
    </section>
<!---------ind section home id--------------->
<!---------ind section dishes id--------------->
<section class="dishes" id="dishes">
    <div class="ll">
    <h4>Albaik Jigjiga yar</h4>
    </div>
   <div class="bb">
    <div class="lamber">
       
        <div class="tel1"><img src="Albaik/1111.png" alt=""></div>
    
    </div>
    <div class="lamber">
       
        <div class="tel"><i class="fas fa-phone"></i><a href="tel:573050">573050</a></div>

        <div class="tel"><span>ZAAD:</span><a href="tel:418884">418884</a></div>

        <div class="tel"><span>EDAHAB:</span><a href="tel:55177">55177</a></div>

        <div class="tel"><i class="fas fa-mobile"></i><a href="tel:0633322255">0633322255</a></div>
      
      </div>
   </div>
   <div class="ll">
   <h4>Albaik Suuqa Hoose</h4>
</div>
   <div class="bb">
    <div class="lamber">
       
        <div class="tel1"><img src="Albaik/1111.png" alt=""></div>
    
    </div>
    <div class="lamber">
       
        <div class="tel"><i class="fas fa-phone"></i><a href="tel:573050">510077</a></div>

        <div class="tel"><span>ZAAD:</span><a href="tel:418884">432122</a></div>

        <div class="tel"><span>EDAHAB:</span><a href="tel:55177">76777</a></div>

        <div class="tel"><i class="fas fa-mobile"></i><a href="tel:0633322255">0636811113</a></div>
      
      </div>
   </div>
   <div class="ll">
   <h4>Albaik Star</h4>
</div>
   <div class="bb">
    <div class="lamber">
       
        <div class="tel1"><img src="Albaik/1111.png" alt=""></div>
    
    </div>
    <div class="lamber">
       
        <div class="tel"><i class="fas fa-phone"></i><a href="tel:573050">560455</a></div>

        <div class="tel"><span>ZAAD:</span><a href="tel:418884">439669</a></div>

        <div class="tel"><span>EDAHAB:</span><a href="tel:55177">92953</a></div>

        <div class="tel"><i class="fas fa-mobile"></i><a href="tel:0633322255">0636383531</a></div>
      
      </div>
   </div>
<div class="ll">
   <h4>Albaik New-Hargaisa</h4>
</div>
   <div class="bb">
    <div class="lamber">
       
        <div class="tel1"><img src="Albaik/1111.png" alt=""></div>
    
    </div>
    <div class="lamber">
       
        <div class="tel"><i class="fas fa-phone"></i><a href="tel:573050">510855</a></div>

        <div class="tel"><span>ZAAD:</span><a href="tel:418884">440977</a></div>

        <div class="tel"><span>EDAHAB:</span><a href="tel:55177">93954</a></div>

        <div class="tel"><i class="fas fa-mobile"></i><a href="tel:0633322255">0633143252</a></div>
      
      </div>
   </div>
 <div class="box-container">
    <div class="box">
        
        <i class="fa">1</i>
        <img src="aadan/1011-removebg-preview.png" alt="">
        <h3>Snack Chicken Meal</h3>
        <div class="starts">
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fas fa-star-half-alt"></i>
        </div>
        <p>2 Piece Chicken + French Freis + Buns + Cola</p>
        <span>price</span>
         <span class="price">$4.5</span>
    </div>
  
   
    <div class="box">
        <i class="fa">2</i>
        
        <img src="aadan/2022-removebg-preview.png" alt="">
        <h3>Super Chicken Meal</h3>
        <div class="starts">
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fas fa-star-half-alt"></i>
        </div>
        <p>4 Piece Chicken + French Freis + Cosleslaw + Buns + Cola</p>
        <span>price</span>
         <span class="price">$7.5</span>
    </div>
    <div class="box">
        
        <i class="fa">3</i>
        <img src="aadan/303_png-removebg-preview.png" alt="">
        <h3>Snack Strips Meal</h3>
        <div class="starts">
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fas fa-star-half-alt"></i>
        </div>
        <p>3 Piece Chicken Boneless + French Freis + Buns + Cola</p>
        <span>price</span>
         <span class="price">$4.8</span>
    </div>
    <div class="box">
        
        <i class="fa">4</i>
        <img src="aadan/404-removebg-preview.png" alt="">
        <h3>Meal Fish Albaikl</h3>
        <div class="starts">
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fas fa-star-half-alt"></i>
        </div>
        <p>4 Piece Chicken Boneless + French Freis + Buns + Cola</p>
        <span>price</span>
         <span class="price">$6.5</span>
    </div>
    <div class="box">
        
        <i class="fa">5</i>
    <img src="aadan/5.ipng-removebg-preview.png" alt="">
    <h3>Super Strips Meal</h3>
    <div class="starts">
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fas fa-star-half-alt"></i>
    </div>
    <p>5 Piece Chicken Boneless + French Freis + Cosleslaw + Buns + Cola</p>
    <span>price</span>
     <span class="price">$7.5</span>
    
</div>
<div class="box">
    
    <i class="fa">6</i>
    <img src="aadan/66_png-removebg-preview.png" alt="">
    <h3>Snack Nuggets Meal</h3>
    <div class="starts">
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fas fa-star-half-alt"></i>
    </div>
    <p>7 Piece Chicken Nuggets + French Freis + Cola</p>
    <span>price</span>
     <span class="price">$6.5</span>
    
</div>
<div class="box">
    
    <i class="fa">7</i>
    <img src="cabdi fataax/sbi-removebg-preview.png" alt="">
    <h3>Cola</h3>
    <div class="starts">
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fas fa-star-half-alt"></i>
    </div>
    <span>price</span>
     <span class="price">$0.5</span>
    
</div>
<div class="box">
    
    <i class="fa">8</i>
    <img src="cabdi fataax/download-removebg-preview.png" alt="">
    <h3>Garlic</h3>
    <div class="starts">
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fas fa-star-half-alt"></i>
    </div>
    <span>price</span>
     <span class="price">$0.50</span>
    
</div>
<div class="box">
    
    <i class="fa">9</i>
    <img src="cabdi fataax/cole-removebg-preview.png" alt="">
    <h3>Coleslaw</h3>
    <div class="starts">
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fas fa-star-half-alt"></i>
    </div>
    <span>price</span>
     <span class="price">$1.00</span>
     
</div>

<div class="box">
    
    <i class="fa">10</i>
    <img src="cabdi fataax/french-removebg-preview.png"alt="">
    <h3>French Freis</h3>
    <div class="starts">
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fas fa-star-half-alt"></i>
    </div>
    <span>price</span>
     <span class="price">$1.5</span>
    
</div>

<div class="box">
    
    <i class="fa">11</i>
    <img src="cabdi fataax/11-removebg-preview.png" alt="">
    <h3>Fillet Albaik</h3>
    <div class="starts">
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fas fa-star-half-alt"></i>
    </div>
    <span>price</span>
     <span class="price">$5.00</span>
   
</div>
<div class="box">
    
    <i class="fa">12</i>
    <img src="cabdi fataax/12-removebg-preview.png" alt="">
    <h3>Zinger Albaik</h3>
    <div class="starts">
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fas fa-star-half-alt"></i>
    </div>
    <span>price</span>
     <span class="price">$4.9</span>
</div>
<div class="box">
    
    <i class="fa">13</i>
    <img src="cabdi fataax/14-removebg-preview.png" alt="">
    <h3>Tortilla Fish</h3>
    <div class="starts">
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fas fa-star-half-alt"></i>
    </div>
    <span>price</span>
     <span class="price">$4.9</span>
   
</div>
<div class="box">
    
    <i class="fa">14</i>
    <img src="cabdi fataax/14-removebg-preview.png" alt="">
    <h3>Mini chico AL BAIK</h3>
    <div class="starts">
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fas fa-star-half-alt"></i>
    </div>
    <span>price</span>
     <span class="price">$4.9</span>
   
</div>
<div class="box">
    
    <i class="fa">15</i>
    <img src="cabdi fataax/15-removebg-preview.png" alt="">
    <h3>Fish sandawich</h3>
    <div class="starts">
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fas fa-star-half-alt"></i>
    </div>
    <span>price</span>
     <span class="price">$4.9</span>
   
</div>
<div class="box">
    
    <i class="fa">16</i>
    <img src="aadan/16_png-removebg-preview.png" alt="">
    <h3>Super Family Chicken</h3>
    <div class="starts">
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fas fa-star-half-alt"></i>
    </div>
    <p>16 Piece Chicken + French Freis + 4 Cosleslaw + 4 Buns + 4 Cola</p>
  
    <span>price</span>
     <span class="price">$24.00</span>
   
</div>
<div class="box">
    
    <i class="fa">17</i>
    <img src="aadan/17-removebg-preview.png" alt="">
    <h3>Super Family Strips</h3>
    <div class="starts">
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fas fa-star-half-alt"></i>
    </div>
    <p>20 Piece Chicken + French Freis + 4 Cosleslaw + 4 Buns + 4 Cola</p>
    <span>price</span>
     <span class="price">$24.00</span>
   
</div>
<div class="box">
    
    <i class="fa">18</i>
    <img src="aadan/18-removebg-preview.png">
    <h3>Family Strips</h3>
    <div class="starts">
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fas fa-star-half-alt"></i>
    </div>
    <p>15 Piece Chicken + French Freis + 3 Cosleslaw + 3 Buns + 3 Cola</p>
    <span>price</span>
     <span class="price">$20.00</span>
   
</div>

<div class="box">
    
    <i class="fa">19</i>
    <img src="aadan/19-removebg-preview.png" alt="">
    <h3>Family Chicken</h3>
    <div class="starts">
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fas fa-star-half-alt"></i>
    </div>
    <p>12 Piece Chicken + French Freis + 3 Cola</p>
    <span>price</span>
     <span class="price">$20.00</span>
   
</div>
 
 <div class="box">
     
    <i class="fa">20</i>
    <img src="aadan/20-removebg-preview.png" alt="">
    <h3>Family Fish</h3>
    <div class="starts">
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fas fa-star-half-alt"></i>
    </div>
    <p>15 Piece Chicken + French Freis + 3 Cosleslaw + 3 Buns + 3 Cola</p>
    <span>price</span>
     <span class="price">$20.00</span>
   
</div>
<div class="box">
    
    <i class="fa">22</i>
    <img src="aadan/Screenshot_2022-03-13_034756-removebg-preview.png" alt="">
    <h3>Piece Strips</h3>
    <div class="starts">
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fas fa-star-half-alt"></i>
    </div>
    <span>price</span>
     <span class="price">$1.5</span>
</div>
<!---<div class="box">
    <img src="Albaik/zingg.png" alt="">
    <h3>Zinger Albaik</h3>
    <div class="starts">
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fas fa-star-half-alt"></i>
    </div>
    <span>price</span>
     <span class="price">$4.9</span>
   
</div>-->
<div class="box">
    
    <i class="fa">23</i>
    <img src="aadan/23-removebg-preview.png" alt="">
    <h3>Strips Meal</h3>
    <div class="starts">
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fas fa-star-half-alt"></i>
    </div>
    <span>price</span>
     <span class="price">$3.8</span>
   
</div>
<div class="box">
    
    <i class="fa">24</i>
    <img src="aadan/24-removebg-preview.png" alt="">
    <h3>Nugets Meal</h3>
    <div class="starts">
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fas fa-star-half-alt"></i>
    </div>
    <span>price</span>
     <span class="price">$4.00</span>
   
</div>

<div class="box">
    
    <i class="fa">25</i>
    <img src="aadan/25-removebg-preview.png" alt="">
    <h3>Piexce Chicken Meal</h3>
    <div class="starts">
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fas fa-star-half-alt"></i>
    </div>
    <span>price</span>
     <span class="price">$3.5</span>
   
</div>
<div class="box">
    
    <i class="fa">26</i>
    <img src="cabdi fataax/bun-removebg-preview.png" alt="">
    <h3>Bunger</h3>
    <div class="starts">
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fas fa-star-half-alt"></i>
    </div>
    <span>price</span>
     <span class="price">$0.25</span>
   
</div>


</div>
 </section>
 <!---</section>
-------ind section dishes id-----------
<section class="oder" id="oder">
    <div class="heading">
        <span>Oder Now</span>
        <h3>Fastest Home Delivery</h3>
    </div>
  --- <div class="icons-container">
        <div class="icons">
        
            <h3>8:00am to 11:00pm</h3>
        </div>
        <div class="icons">
           
            <h3>000000000</h3>
        </div>
        <div class="icons">
           
            <h3>Hargaisa, soomaaliland - 0000</h3>
        </div>
    </div>-
    <form onsubmit="event.preventDefault(); validateForm( )" action="">
        <div class="flex">
            <div class="inbutBox">
                <span>Your-name</span>
                <input type="text" placeholder="First-Name" name="" id="f-name">
            </div>
            <div class="inbutBox">
                <span>Last-Name</span>
                <input type="text" placeholder=" Your Last Name" name="" id="l-name">
            </div>
        </div>
        <div class="flex">
            <div class="inbutBox">
                <span>Email</span>
                <input type="text" placeholder="Yuor Email" name="" id="f-name">
            </div>
            <div class="inbutBox">
                <span>Phone-Number</span>
                <input type="number" placeholder="Your Phone Number" name="" id="l-name">
            </div>
        </div>
        <div class="flex">
            <div class="inbutBox">
                <span>Your-oder</span>
                <input type="text" placeholder="food you want" name="" id="oder">
            </div>
            <div class="inbutBox">
                <span>How much</span>
                <input type="number" placeholder="numbrs or oders" name="" id="much">
            </div>
        </div>
        <div class="flex">
            <div class="inbutBox">
                <span>Your details</span>
                <input type="text" placeholder="Your Message" name="" id="">
            </div>
            <div class="inbutBox">
                <span>pick up time</span>
                <input type="datetime-local">
            </div>
        </div>
        <div class="flex">
            <div class="inbutBox">
                <textarea placeholder="your address" id="" cols="30" rows="10"></textarea>
            </div>
            <div class="inbutBox">
                <iframe class="map" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d125905.18384618706!2d43.99431259641532!3d9.
                548892896447644!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1628bf87108c7219%3A0x61638d9da9bd62d2!2sHar
                geisa!5e0!3m2!1sen!2sso!4v1641350684155!5m2!1sen!2sso" allowfullscreen="" loading="lazy"></iframe>
            </div>
        </div>
       
       
            <input type="submit" value="proced to oder" class="btn">
    </form>
</section>--->

<section class="home" id="about">


    
        <center> <span class="span">About Us</span></center>
    
           <div class=" slide1">
            
    
           <div class="image">
              <img src="albaik/CpkhSoSWIAAKNKG.jpg" alt="">
           </div>
           <div class="content">
            <span>Albaik</span>
            <p>albaik waa shirkad wayn oo ku taala talka saudi arabia taasi oo iibisa 
                cuntooyinka sida digaaga noocyadiisa kala duwan iyo kaluunka 
                </p>
                <div class="icons-1">
                    <a href="https://www.facebook.com/Albaikso"> <div class="icon1"><i class="fab fa-facebook-square"></i></div></a>
        
                    <a href="#"><div class="icon2"><i class="fab fa-instagram-square"></i></div></a>
                    <a href="https://wa.me/00252633454984"
                  class="whatsapp_float" target="_blank"> <div class="icon3"><i class="fab fa-whatsapp"></i></div></a>
                </div>
                  <div class="ler">
                  
                  </div>
                
        </div>
    
        </div>
       
       
         
       
    
   
 
    </section>
    <!----
<section class="dishes" id="dishes">
    <center><span class="sub-heading"> Menu</span></center>
    <div class="box-container">
        <div class="box">
            
            <i class="fa">1</i>
            <img src="aadan/1-removebg-preview (1).png" alt="">
            <h3>Snack Chicken Meal</h3>
            <div class="starts">
                <i class="fa fa-star" aria-hidden="true"></i>
                <i class="fa fa-star" aria-hidden="true"></i>
                <i class="fa fa-star" aria-hidden="true"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <p>2 Piece Chicken + French Freis + Buns + Cola</p>
            <span>price</span>
             <span class="price">$4.5</span>
        </div>
      
       
        <div class="box">
            <i class="fa">2</i>
            
            <img src="aadan/2-removebg-preview (1).png" alt="">
            <h3>Super Chicken Meal</h3>
            <div class="starts">
                <i class="fa fa-star" aria-hidden="true"></i>
                <i class="fa fa-star" aria-hidden="true"></i>
                <i class="fa fa-star" aria-hidden="true"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <p>4 Piece Chicken + French Freis + Cosleslaw + Buns + Cola</p>
            <span>price</span>
             <span class="price">$7.5</span>
        </div>
        <div class="box">
            
            <i class="fa">3</i>
            <img src="aadan/3_png-removebg-preview.png" alt="">
            <h3>Snack Strips Meal</h3>
            <div class="starts">
                <i class="fa fa-star" aria-hidden="true"></i>
                <i class="fa fa-star" aria-hidden="true"></i>
                <i class="fa fa-star" aria-hidden="true"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <p>3 Piece Chicken Boneless + French Freis + Buns + Cola</p>
            <span>price</span>
             <span class="price">$4.8</span>
        </div>
        <div class="box">
            
            <i class="fa">4</i>
            <img src="aadan/4-removebg-preview (1).png" alt="">
            <h3>Meal Fish Albaikl</h3>
            <div class="starts">
                <i class="fa fa-star" aria-hidden="true"></i>
                <i class="fa fa-star" aria-hidden="true"></i>
                <i class="fa fa-star" aria-hidden="true"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <p>4 Piece Chicken Boneless + French Freis + Buns + Cola</p>
            <span>price</span>
             <span class="price">$6.5</span>
        </div>
        <div class="box">
            
            <i class="fa">5</i>
        <img src="aadan/5.ipng-removebg-preview.png" alt="">
        <h3>Super Strips Meal</h3>
        <div class="starts">
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fas fa-star-half-alt"></i>
        </div>
        <p>5 Piece Chicken Boneless + French Freis + Cosleslaw + Buns + Cola</p>
        <span>price</span>
         <span class="price">$7.5</span>
        
    </div>
    <div class="box">
        
        <i class="fa">6</i>
        <img src="aadan/66_png-removebg-preview.png" alt="">
        <h3>Snack Nuggets Meal</h3>
        <div class="starts">
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fas fa-star-half-alt"></i>
        </div>
        <p>7 Piece Chicken Nuggets + French Freis + Cola</p>
        <span>price</span>
         <span class="price">$6.5</span>
        
    </div>
    <div class="box">
        
        <i class="fa">7</i>
        <img src="cabdi fataax/sbi-removebg-preview.png" alt="">
        <h3>Cola</h3>
        <div class="starts">
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fas fa-star-half-alt"></i>
        </div>
        <span>price</span>
         <span class="price">$0.5</span>
        
    </div>
    <div class="box">
        
        <i class="fa">8</i>
        <img src="cabdi fataax/download-removebg-preview.png" alt="">
        <h3>Garlic</h3>
        <div class="starts">
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fas fa-star-half-alt"></i>
        </div>
        <span>price</span>
         <span class="price">$0.50</span>
        
    </div>
    <div class="box">
        
        <i class="fa">9</i>
        <img src="cabdi fataax/cole-removebg-preview.png" alt="">
        <h3>Coleslaw</h3>
        <div class="starts">
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fas fa-star-half-alt"></i>
        </div>
        <span>price</span>
         <span class="price">$1.00</span>
         
    </div>
    
    <div class="box">
        
        <i class="fa">10</i>
        <img src="cabdi fataax/french-removebg-preview.png"alt="">
        <h3>French Freis</h3>
        <div class="starts">
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fas fa-star-half-alt"></i>
        </div>
        <span>price</span>
         <span class="price">$1.5</span>
        
    </div>
    
    <div class="box">
        
        <i class="fa">11</i>
        <img src="cabdi fataax/11-removebg-preview.png" alt="">
        <h3>Fillet Albaik</h3>
        <div class="starts">
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fas fa-star-half-alt"></i>
        </div>
        <span>price</span>
         <span class="price">$5.00</span>
       
    </div>
    <div class="box">
        
        <i class="fa">12</i>
        <img src="cabdi fataax/12-removebg-preview.png" alt="">
        <h3>Zinger Albaik</h3>
        <div class="starts">
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fas fa-star-half-alt"></i>
        </div>
        <span>price</span>
         <span class="price">$4.9</span>
    </div>
    <div class="box">
        
        <i class="fa">13</i>
        <img src="cabdi fataax/14-removebg-preview.png" alt="">
        <h3>Tortilla Fish</h3>
        <div class="starts">
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fas fa-star-half-alt"></i>
        </div>
        <span>price</span>
         <span class="price">$4.9</span>
       
    </div>
    <div class="box">
        
        <i class="fa">14</i>
        <img src="cabdi fataax/14-removebg-preview.png" alt="">
        <h3>Mini chico AL BAIK</h3>
        <div class="starts">
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fas fa-star-half-alt"></i>
        </div>
        <span>price</span>
         <span class="price">$4.9</span>
       
    </div>
    <div class="box">
        
        <i class="fa">15</i>
        <img src="cabdi fataax/15-removebg-preview.png" alt="">
        <h3>Fish sandawich</h3>
        <div class="starts">
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fas fa-star-half-alt"></i>
        </div>
        <span>price</span>
         <span class="price">$4.9</span>
       
    </div>
    <div class="box">
        
        <i class="fa">16</i>
        <img src="aadan/16_png-removebg-preview.png" alt="">
        <h3>Super Family Chicken</h3>
        <div class="starts">
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fas fa-star-half-alt"></i>
        </div>
        <p>16 Piece Chicken + French Freis + 4 Cosleslaw + 4 Buns + 4 Cola</p>
      
        <span>price</span>
         <span class="price">$24.00</span>
       
    </div>
    <div class="box">
        
        <i class="fa">17</i>
        <img src="aadan/17-removebg-preview.png" alt="">
        <h3>Super Family Strips</h3>
        <div class="starts">
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fas fa-star-half-alt"></i>
        </div>
        <p>20 Piece Chicken + French Freis + 4 Cosleslaw + 4 Buns + 4 Cola</p>
        <span>price</span>
         <span class="price">$24.00</span>
       
    </div>
    <div class="box">
        
        <i class="fa">18</i>
        <img src="aadan/18-removebg-preview.png">
        <h3>Family Strips</h3>
        <div class="starts">
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fas fa-star-half-alt"></i>
        </div>
        <p>15 Piece Chicken + French Freis + 3 Cosleslaw + 3 Buns + 3 Cola</p>
        <span>price</span>
         <span class="price">$20.00</span>
       
    </div>
    
    <div class="box">
        
        <i class="fa">19</i>
        <img src="aadan/19-removebg-preview.png" alt="">
        <h3>Family Chicken</h3>
        <div class="starts">
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fas fa-star-half-alt"></i>
        </div>
        <p>12 Piece Chicken + French Freis + 3 Cola</p>
        <span>price</span>
         <span class="price">$20.00</span>
       
    </div>
     
     <div class="box">
         
        <i class="fa">20</i>
        <img src="aadan/20-removebg-preview.png" alt="">
        <h3>Family Fish</h3>
        <div class="starts">
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fas fa-star-half-alt"></i>
        </div>
        <p>15 Piece Chicken + French Freis + 3 Cosleslaw + 3 Buns + 3 Cola</p>
        <span>price</span>
         <span class="price">$20.00</span>
       
    </div>
    <div class="box">
        
        <i class="fa">22</i>
        <img src="aadan/Screenshot_2022-03-13_034756-removebg-preview.png" alt="">
        <h3>Piece Strips</h3>
        <div class="starts">
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fas fa-star-half-alt"></i>
        </div>
        <span>price</span>
         <span class="price">$1.5</span>
    </div>
   <div class="box">
        <img src="Albaik/zingg.png" alt="">
        <h3>Zinger Albaik</h3>
        <div class="starts">
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fas fa-star-half-alt"></i>
        </div>
        <span>price</span>
         <span class="price">$4.9</span>
       
    </div>
    <div class="box">
        
        <i class="fa">23</i>
        <img src="aadan/23-removebg-preview.png" alt="">
        <h3>Strips Meal</h3>
        <div class="starts">
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fas fa-star-half-alt"></i>
        </div>
        <span>price</span>
         <span class="price">$3.8</span>
       
    </div>
    <div class="box">
        
        <i class="fa">24</i>
        <img src="aadan/24-removebg-preview.png" alt="">
        <h3>Nugets Meal</h3>
        <div class="starts">
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fas fa-star-half-alt"></i>
        </div>
        <span>price</span>
         <span class="price">$4.00</span>
       
    </div>
    
    <div class="box">
        
        <i class="fa">25</i>
        <img src="aadan/25-removebg-preview.png" alt="">
        <h3>Piexce Chicken Meal</h3>
        <div class="starts">
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fas fa-star-half-alt"></i>
        </div>
        <span>price</span>
         <span class="price">$3.5</span>
       
    </div>
    <div class="box">
        
        <i class="fa">26</i>
        <img src="cabdi fataax/bun-removebg-preview.png" alt="">
        <h3>Bunger</h3>
        <div class="starts">
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fa fa-star" aria-hidden="true"></i>
            <i class="fas fa-star-half-alt"></i>
        </div>
        <span>price</span>
         <span class="price">$0.25</span>
       
    </div>
    
    
    </div>-->
     </section>
<section class="lood">
    <div class="louding">
        <img src="Albaik/logo.jpg" alt="">
    </div>
</section> 

<section id="footer">
    <div class="footer">
       <!--- <div class="box-footer">
            <h3>Dishes</h3>
           
               
                <div class="dish">
                    <div class="dish1">    <a href="#snack1">  <span class="a12">Snack Chicken Meal</span></a><br>
                        <a href="#super1">  <span class="a12">Super Chicken Meal</span></a><br>
                        <a href="#snack2">  <span class="a12">Snack Strips Mea</span></a><br>
                        <a href="#meal1">   <span class="a12">Meal Fish Albaikl</span></a><br>
                        <a href="#super2">  <span class="a12">Super Strips Meal</span></a><br>
                        <a href="#snack3">  <span class="a12">Snack Nuggets Meal</span></a><br>
                        <a href="#cola">  <span class="a12">Cola</span></a><br>
                        <a href="#coleslaw">  <span class="a12">Coleslaw</span></a><br>
                        <a href="#french">  <span class="a12">French fries</span></a><br>
                        <a href="#fish1">  <span class="a12">Fish Fillet Meal</span></a><br>
                        <a href="#family1">  <span class="a12">Family Fish</span></a><br>
                        <a href="#family2">  <span class="a12">Family Chicken</span></a><br>
                    </div>
            
                <div class="dish1">
                        <a href="#piece">  <span class="a12">Piece Strips</span></a><br>
                        <a href="#piece1">  <span class="a12">Piece Chicken Meal</span></a><br>
                        <a href="#strips3">  <span class="a12">Strips Meal</span></a><br>
                        <a href="#nuggets">  <span class="a12">Nuggets Meal</span></a><br>
                        <a href="#fish2">  <span class="a12">Fish Sandwich</span></a><br>
                        <a href="#super5">  <span class="a12">Super Family Strips</span></a><br>
                        <a href="#family3">  <span class="a12">Family Strips</span></a><br>
                        <a href="#zinger">  <span class="a12">Zinger Albaik</span></a><br>
                        <a href="#ter">  <span class="a12">Tertilla Fish</span></a><br>
                        <a href="#mini">  <span class="a12">Mini Chice Albaik</span></a><br>
                    </div>
                </div>
            
        </div>-->
        <hr>
        <div class="box-footer">
            <h3>Social-Contact Us</h3>
         <div class="dish1">
            <a href="https://www.facebook.com/Albaikso"> Facebook <br> <br></a>
             <a href="#">Instgram</a> <br> <br>
           
            <a href="https://wa.me/00252633454984"
             class="whatsapp_float" target="_blank">whatsapp</a>
         </div>
           
        </div><hr>
        <div class="box-footer">
            <h3>Numbers-Contact Us</h3>
            <div class="dish1">
              <a href="tel:0636811113">0636811113</a> <br> <br>
            </div>
        </div><hr>
      
        <div class="box-footer">
            <h3>Locations</h3>
          <div class="dish1">
       Suuqa hoose</span><br> <br>
            Jigjiga yar<br> <br>
           Star onley <br> <br>
           New New-Hargaisa
          </div>
        </div>
    </div>
    <hr>
    <center><div class="brek">
       <h3> Copyright-Albaik-2022</h3>
    </div></center>
    
</section>

         <style>
            *{
    font-family: 'Nunito', sans-serif;
    margin: 0; padding: 0;
    box-sizing: border-box;
    text-decoration: none;
    outline: none; border: none;
    text-transform: capitalize;
    transition: all .2s linear;
}
html{
    font-size: 62.5%;
    overflow-x: hidden;
    scroll-padding-top: 5.5rem;
    scroll-behavior: smooth;

}
section{
    padding:0;
 
}

section:nth-child(even){
   background-color: rgb(255, 255, 255);;
}
.sub-heading{
    text-align: center;
    color: rgb(255, 0, 0);
    font-size: 2rem;
    padding-top: 1rem;
}
.heading{
    text-align: center;
    color:black;
    font-size: 3rem;
    padding-bottom: 3rem;
    text-transform: uppercase;
}
.btn{
   background: black;
   font-size: 1.7rem;
   border-radius: .8rem;
   padding: .5rem 1.5rem;
   color: #fff;
   display: inline-block;
   cursor: pointer;padding: 1rem 1.5rem;
 
}
.btn:hover{
    background: rgb(255, 0, 0);
    letter-spacing: .1rem;
}
	.header {
position:fixed;
top: 0; left: 0; right: 0;
background: #fff;
padding: 1rem 7%;
display: flex;
align-items: center;
justify-content: space-between;
z-index: 1000;
box-shadow: 10px 10px 5px rgb(192, 189, 189);
    }
    header .logo{
        color: var(--black);
        font-size: 4rem;
        font-weight: bolder;
        display: flex;
    }
    .aaa{
        font-size: 4rem;
        color: black;

    }
    .hhh{
        font-size: 1.5rem;
        color: black;
        margin-top: 2rem;
    }
     .logo i{
        color: var(--green);
    }
    .logo i span{
        font-size: .1rem;
    }
    .header .navbar a {
      font-size: 1.7rem;
      border-radius: .5rem;
      padding: .5rem 1.5rem;
      color: var(--light-color);
    }
    .logo i{
        color:red;
    }
header .icons i,
header .icons a{
    cursor: pointer;
    margin-left: .5rem;height: 4.5rem;
    line-height: 4.5rem;
    width: 4.5rem;
    text-align: center;
    font-size: 1.7rem;
    color: rgb(255, 0, 0);
    border-radius: 50%;
    background: #eee;
    background-color: rgb(255, 255, 255);

}
  
   
   .icons a:hover
   {
       color: #fff;
       background-color: rgb(255, 0, 0);
   }
       #menu-bars{
           display: none;
       }
       #search-form{
        position: fixed;
        top: 110%; left: 0;
        height: 100%;width: 100%;
        z-index: 1004;
        background: rgba(0, 0, 0, .8);
        display: flex;
        align-items: center;
        justify-content: center;
        
    }
    #search-form.active{
        top: 0;
    }
    #search-form #search-box{
        width: 50rem;
        border-bottom: .1rem solid #fff;
        padding: 1rem 0;
        color: #fff;
        font-size: 3rem;
        text-transform: none;
        background: none;
    }
    #search-form #search-box::placeholder{
        color: #eee;

    }
    #search-form #search-box::-webkit-search-cancel-button{
        -webkit-appearance:none;
    }
    #search-form label{
        color: #fff;
        cursor: pointer;
        font-size: 3rem;
 }
 #search-form label:hover{
     color: rgb(255, 0, 0);
 }
 #search-form #close{
     position: absolute;
     color: #fff;
     cursor: pointer;
     top: 2rem; right: 3rem;
     font-size: 5rem;
 }
 #search-form #close:hover{
     color: rgb(255, 0, 0);
 }
   
    .home .home-slider .slide{
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        gap: 2rem;
        padding-top: 2rem;
        padding-left: 2rem;
        padding-right: 2rem;
    }
    .home-slider{
        padding-top: 50%;
    }

    .content{
        flex: 1 1 45rem;
    }
      .home{
          padding-top: 5rem;
      }
     .image{
        flex: 1 1 45rem;
    }

    img{
        width: 100%;
        height: 2;
    }

    .content span{
        color: rgb(255, 0, 0);
        font-size: 2.5rem;
    }
    .content h3{
        color: black;
        font-size: 7rem;
    }
     .content p{
         color:rgb(97, 91, 91);
         font-size: 2.2rem;
         padding: 5rem 0;
         align-items: 1.5;
     }
     .ll h4{
        text-align: center;
        justify-content: center;
        font-size: 3rem;
    }
     .box-container{
         display: grid;
         grid-template-columns: repeat(auto-fit, minmax(28rem, 1fr));
         gap: 1.5rem;
         padding-bottom: 2rem;
      
     
     }
     .box-container-1{
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(28rem, 1fr));
        gap: 1.5rem;
        padding-top: 2rem;
     
    
    }
    .about-slider{
      padding: 2rem;
    }
     
       .box-container{
         width: 100%;
         background-color: rgb(247, 29, 29);
     }
     .fa{
         background-color: #ffff;
         padding: 1rem;
         border-radius: 50%;
         font-size: 2rem;
     }
     .box{
        padding: 2.5rem;
        background: red;
        border-radius: .5rem; 
        position: relative;
        overflow: hidden;
        text-align: center;
        margin-top: .5rem;
        border: 1px solid rgb(53, 49, 49);
      
    }
    .box-container .box p{
        color: #ffff;
    }
    .box-1{
        padding: 2.5rem;
        background:red;
        border-radius: .5rem;
        position: relative;
        overflow: hidden;
        text-align: center;
       
    }
    #menu{
        background-color: rgb(255, 255, 255);
        border: 2px solid red;
    }
    #menu  .box p{
        font-size: 1.7rem;
        color: #fff;
    }
      .menu{
          padding: 2rem;
      }
     .box-container .fa-heart,
     .box-container .fa-ey
     {
       position: absolute;
        top: 1.5rem;
        background: #eee;
        border-radius: 50%;
        height: 5rem;
        width: 5rem;
        line-height: 5rem;
        font-size: 2rem;
        color: black;
        
    }
    .home-slider-1{
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(28rem, 1fr));
        gap: 1.5rem;
        padding-top: 2rem;
     
    }
    .wrapp-1 .image{
        height: 15rem;
    }
    .wrapp-1
    {
        padding: 2.5rem;
        background: #fff;
        border-radius: .5rem; 
        position: relative;
        overflow: hidden;
        text-align: center;
    }
      .fa-eye{
        right: -15rem;

    }
    
     .dishes .box-container .box .fa-heart{
         left:-15rem
     }
    
     .dishes .box-container .box:hover .fa-eye{
        right: 1.5rem;

    }

    .dishes .box-container .box:hover .fa-heart{
         left:1.5rem
     }
     .dishes .box-container .box .fa-eye:hover{
       color: #fff;
       background: rgb(255, 0, 0);

    }

     .box-container .fa-heart:hover{
        color: #fff;
        background: rgb(255, 60, 0);
 
     }
    .box img{
         height: 14rem;
         margin: 1rem 0;
         
     }
      .box h3{
         color: rgb(255, 255, 255);
         font-size: 2.5rem;

     }
     .menu .box p,
     .box p{
         color: #fff;
         font-size: 1.7rem;

     }
     .heading{
         color: #fff;
         letter-spacing: .5rem;
         padding-top: 1rem;
     }
     .sub-heading{
         font-size: 5rem;
         border-bottom: 2px solid rgb(255, 0, 0);
     }
     .dishes .box-container .starts{
       padding: 1rem 0;
        
    }
    .box .starts i{
       font-size: 1.7rem;
       color: rgb(255, 0, 0);
         
     }
      .box span{
         color: rgb(255, 255, 255);
         font-weight: bolder;
         margin-right: 3rem;
         font-size: 2.5rem;
     }
     .wrapp{
         width: 100%;
     }
     .price{
         color: rgb(255, 255, 255);
     }
     .dishes{
         padding: 2rem;
       
         
     }
     #dishes{
        background-color: rgb(255, 255, 255);
        border: 2px solid red;
     }
     button{
         background-color: rgb(253, 0, 0);
         padding: 1rem;
         padding-top: .7rem;
         padding-bottom: .7rem;
         border-radius: .5rem;
         border: 1 solid black;
         width: 6rem;
     }
     button:hover{
       background-color: rgb(97, 90, 90);
       color: #fff;
       letter-spacing: .1rem;
     }
     /*----oder-----*/
     .icons{
       flex-wrap: wrap;
       gap: 1.5rem;
       align-items: center;
     }
     .icons span{
         color: rgb(255, 2, 2);
         font-size: 5rem;
         padding-top: 1rem;
         border-bottom: 2px solid rgb(255, 2, 2);
         font-family:  "Brush Script MT";
         
     }
     .home .span,
     .menu .sub-heading,
     .dishes .sub-heading{
        font-family: "Brush Script MT";
     }
     .home .span{
         color: rgb(255, 43, 43);
         font-size: 4rem;
         padding-top: -1rem;
     }
     .icons h3{
         color: black;
         font-size:4rem ;
        
     }
     .row-22{
         display: flex;
         flex-wrap: wrap;
         gap: 1.5rem;
         align-items: center;
        
     }
     .baout-2{
         flex:1 1 45rem;
     }
    
    .contact{
        flex:1 1 45rem;
    }
    .contact h3{
        color: black;
        font-size: 4rem;
        padding: 5rem 0;
        font-family: Arial (sans-serif);
    }
    .contact p{
        color: rgb(58, 57, 57);
        font-size: 5rem;
        padding: 5rem 0;
        line-height: 2;
    }
    .contact-container{
        display: flex;
        align-items: center;
        justify-content: space-between;
        width: 50%;
        
        
    }
    .icon{
        border-radius: 50%;
        line-height: 5rem;
        font-size: 2rem;
        color: rgb(247, 0, 0);
        border-radius: 2rem;
    }
    
    .icon:hover{
        color: black;
    }
    .footer{
      
        display: flex;
        justify-content: space-between;
      
        color: black;
        font-size: 3rem;
        padding-top: 2rem;
        padding-left: 1rem;
        padding-right: 3rem;
    }

   #footer{
       background-color: red;
   }
   .footer h3,
   .footer span:hover{
      
    
       color: rgb(255, 255, 255);
   } 
   .lamber img {
       display: flex;
       justify-content: space-between;
       width: 100%;
   }
   .lamber{
       display: flex;
       justify-content: space-between;
   }
   .lamber span, .lamber i, .lamber a{
       color: red;
       font-size: 3rem;
       text-decoration: none;
      
     
   }
   .bb{
       display: block;
       justify-content: space-between;
   }
   .footer span{
    font-size: 1rem;
    
  
   }

 
   .break h3{
       color: black;
       font-size: 1.3rem;
       align-items: center;
   }
   .slide1 .span1{
       background-color:rgb(54, 52, 52);
       padding-left: 2rem;
       padding-right: 2rem;
       padding-top: 1rem;
       padding-bottom: 1rem;
       color: #fff;
       font-size: 1.5rem;
       width: 6rem;
       border-radius: 1rem;
      
   } .slide1 .span1:hover{
       background-color: rgb(255, 0, 0);
   }

   .ler{
    margin-top: 2rem;
    padding-bottom: 1rem;
   }
   .slide1{
       display: flex;
       flex-wrap: wrap;
       gap: 1.5rem;
   }
   .slide1 .content{
       padding-left: 2rem;
       padding-bottom: 1rem;
   }
   .slide1 span{
       font-size: 5rem;
   }
   .slide1 .icons-1{
       display: flex;
       font-size: 4rem;
       color: rgb(255, 0, 0);
       justify-content: space-between;
       width: 70%;
   }
   .slide1 .icons-1 a .icon1:hover
   {
     color: rgb(51, 51, 197);
   }
   .slide1 .icons-1 a .icon2:hover
   {
     color: rgb(155, 44, 44);
   }
   .slide1 .icons-1 a .icon3:hover
   {
     color: rgb(37, 214, 52);
   }
   .slide1 img{
       border-radius: .5rem;
       padding-right: 2rem;
       padding-left: 2rem;
       padding-bottom: 2rem;
   }
   #menu p{
    font-size: 1.3rem;
    
    color: rgb(0, 0, 0);
}
#menu .box{
    border: 2px solid rgb(235, 6, 6);
}
.box br{
    display: none;
}
 .slide1 a{
    text-decoration: none;
    color: rgb(255, 0, 0);
}
.footer a{
    text-decoration: none;
    color: black;
}
.dish{
    display: flex;
    justify-content: space-between;
   
   
}

.dish1{
    padding-right: 2rem;
    border-left: 2px solid rgb(255, 0, 0);
    border-top-left-radius: 1rem;
    padding-right: 1rem;
    border-bottom-left-radius: 1rem;
}
.dish1 span{
    padding-left: 1rem;
}

.more h3{
    font-size: 3rem;
    color: black;
}
.more p{
    padding: 1rem;
    font-size: 1.5rem;
    color: black;
    letter-spacing: -.1rem;
}
.video video{
    width: 50%;
    height: 25rem;
    color: black;
}

.lood{
    position:fixed;
    top: 0; left: 0; right: 0; bottom: 0;
    background: #fff;
    padding: 1rem 7%;
    display: flex;
    align-items: center;
    justify-content: space-between;
    z-index: 1000;
   
    background-color: rgb(197, 197, 197);
}
.louding{
   height: 200px;
   width: 200px;
    margin-left: 35%;
    font-size: 3rem;
    boxx-sizing:border-box;
    border-radius: 50%;
    border-top: 11px solid rgb(200, 255, 0);
    position: relative;
    animation:  a1 2s linear infinite;
}
.louding::after, .louding::before{
    content: '';
    width: 200px;
    height: 200px;
    position: absolute;
    left: 0;
    top: -10px;
    boxx-sizing:border-box;
    border-radius: 50%;
}

.louding::after{
    border-top: 10px solid rgb(255, 0, 0);
    transform: rotate(120deg);
}
.louding::before{
    border-top: 16px solid rgb(30, 255, 0);
    transform: rotate(240deg);
}
.louding img{
    position: absolute;
    width: 190px;
    height: 190px;
    color: aliceblue;
    text-align: center;
    line-height: 200px;
    border-radius: 60%;
    animation:  a2 2s linear infinite;
}
.fade-out{
    top: 110%;
    opacity: 0;
}

@keyframes a1{
    to{
        transform: rotate(360deg);
    }
}
@keyframes a2{
    to{
        transform: rotate(-360deg);
    }
}




































    @media (max-width:991px)
    {
        html{
            font-size: 55%; 
        }
        header{
            padding: 1rem 2rem;
        }
    }
    @media (max-width:761px)
    {
        .icons #menu-bars{
            display: inline-block;
        }
       .navbar{
            position: absolute;
            top: 100%; left: 0; right: 0;
            background-color: #fff;
            border-top: .1rem solid rgba(0,0,0,.1);
            padding: 1rem;
            clip-path: polygon(0 0, 100% 0, 100% 0, 0 0);
        }
        .navbar.active{
            clip-path:polygon(0 0, 100% 0, 100% 100%, 0% 100%);
        }
        .navbar a{
            display: block;
            padding: 1.5rem;
            margin: 1rem;
            font-size: 2rem;
            background-color: #eee;
        }
        .baout-2{
            width: 100%;
        }
        .hhh{
            margin-right: .5rem;
            }
        .footer{
            display: block;
            align-items: center;
            justify-content: space-between;
            padding-left: 12rem;
        }
        .footer h3{
            font-size: 2rem;
        }
        .dish{
            width: 80%;
        }
        .slide1{
            width: 100%;
        }
        .slide1 img{
            padding: 1rem;
        }
        #menu p{
            font-size: 1rem;
            color: rgb(0, 0, 0);
            padding-bottom: 1.2rem;
        }
        .box h3,
        .box span{
            font-size: 2rem;
        }
        .box img{
          
            height: 65%;
        }
        .box br{
            display: inline-block;
        }
        .menu .box  img{
            width: 60%;
        }
        .box .col, .p img{
            padding-bottom: -4rem;
        }
        
        .louding{
            margin-left: 25%;
        }
        .content h3{
            font-size: 2.5rem;
        }
        .lamber span, .lamber i, .lamber a{
            color: red;
            font-size: 1.7rem;
            text-decoration: none;
           
          
        }
    }
    @media (max-width:450px)
    {
        html{
            font-size: 50%; 
        }
        .lamber span, .lamber i, .lamber a{
            color: red;
            font-size: 1.2rem;
            text-decoration: none;
           
          
        }
       
        .dishes .box-container .box img{
            height: auto;
           width: 100%;
        }
        
    }
         </style>   

<!----------------letest js-------------->
<script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
<script src="Albik.js"></script>
<script>
    let menu =document.querySelector('#menu-bars');
let navbar =document.querySelector('.navbar');

menu.onclick = () =>
{
    menu.classList.toggle('fa-times');
    
    navbar.classList.toggle('active');
}

var swiper = new Swiper(".home-slider", {
   spaceBetween:30,
 centeredslides:true,
autoplay:{
     delay:3000,
     desableOnInteration:false,
   },
pagination:
  {
     el: ".swiper-pagination",
     clickable: true,
    },
    loop:true
  });

  function loader(){
    document.querySelector('.lood').classList.add('fade-out');
  
  }
  function fadeOut (){
    setInterval(loader, 3000);
  }
  
  window.onload = fadeOut;
</script>
</body></html>