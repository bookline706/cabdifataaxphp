let thisPage = 1;
let limit = 18;
let list = document.querySelectorAll('.list .item');

function loadItem(){
    let beginGet = limit * (thisPage - 1);
    let endGet = limit * thisPage - 1;
    list.forEach((item, key)=>{
        if(key >= beginGet && key <= endGet){
            item.style.display = 'block';
        }else{
            item.style.display = 'none';
        }
    })
    listPage();
}
loadItem();
function listPage(){
    let count = Math.ceil(list.length / limit);
    document.querySelector('.listPage').innerHTML = '';

    if(thisPage != 1){
        let prev = document.createElement('li');
        prev.className = 'back';
        prev.innerText = 'PREV';
        prev.setAttribute('onclick', "changePage(" + (thisPage - 1) + ")");
        document.querySelector('.listPage').appendChild(prev);
    }
    
    for(i = 1; i <= count; i++){
        let newPage = document.createElement('li');
        newPage.className = 'num';
        newPage.setAttribute('onclick', "changePage(" + i + ")");
        document.querySelector('.listPage').appendChild(newPage);
    }
    
    if(thisPage != count){
        let next = document.createElement('li');
        next.className = 'next';
        next.innerText = 'NEXT';
        next.setAttribute('onclick', "changePage(" + (thisPage + 1) + ")");
        document.querySelector('.listPage').appendChild(next);
       
    }
}
function changePage(i){
    thisPage = i;
    loadItem();
}















//list galery 
let thisPag = 1;
let limist = 18;

let lists = document.querySelectorAll('.lists-galery .items');
//let lis = document.querySelector('listPag');

function loadIte(){
 /*   let li = '';
    if(page > 1)
    {
        li +='<'
    }
    if(page < allpage)
    {
        li +='>'
    }
    */
    let beginGet = limist * (thisPag - 1);
    let endGet = limist * thisPag - 1;
    lists.forEach((item, key)=>{
        if(key >= beginGet && key <= endGet){
            item.style.display = 'block';
        }else{
            item.style.display = 'none';
        }
    })
  //  lis.innerHTML = li;
    listPag();
}
loadIte();
function listPag(){
    let count = Math.ceil(lists.length / limist);
    document.querySelector('.listPag').innerHTML = '';
   /// document.querySelector('.listall').innerHTML = '';
   
   if(thisPag != 1){
    let pre = document.createElement('li');
    pre.className = 'back';
    pre.innerText = 'PREV';
    pre.setAttribute('onclick', "changePag(" + (thisPag - 1) + ")");
    document.querySelector('.listPag').appendChild(pre);
}

for(i = 1; i <= count; i++){
    let newPag = document.createElement('li');
    newPag.className = 'num';
    newPag.setAttribute('onclick', "changePag(" + i + ")");
    document.querySelector('.listPag').appendChild(newPag);
}

if(thisPag != count){
    let next = document.createElement('li');
    next.className = 'next';
    next.innerText = 'NEXT';
    next.setAttribute('onclick', "changePag(" + (thisPag + 1) + ")");
    document.querySelector('.listPag').appendChild(next);
   
}
}
function changePag(i){
    thisPag = i;
    loadIte();
}
