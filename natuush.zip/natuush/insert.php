


<?php

$conn = mysqli_connect("localhost", "root", "" , "natuush");

$error = '';
$output = '';
if(isset($_POST['submit'])){
 
$array = explode("\r\n", $_POST["name"]);

$email_array = array_unique($array);

$query = "
INSERT INTO test 
(name) 
VALUES ('".implode("'),('", $email_array)."')
";

$statement = $conn->prepare($query);

$statement->execute();

$error = '<label class="text-success">Data Inserted Successfully</label>';
}
?>

<form action="" method="post">
     <table>
        <thead>
            <th>#</th>
            <th>input</th>
        </thead>
        <tr>
        <td> <input type="number" name="SL" value="1"></td>
       
    <td>  <input type="text" name="name" id=""></td>
    </tr>
    <tr>
        <td><input type="number" name="SL" value="2"></td>
       
    <td>  <input type="text" name="name" id=""></td>
    </tr>
    <tr>
        <td> <input type="number" name="SL" value="3"></td>
       
    <td>  <input type="text" name="name" id=""></td>
    </tr>
    <tr>
        <td><input type="number" name="SL" value="4"></td>
       
    <td>  <input type="text" name="name" id=""></td>
    </tr>
    </table>
    <button type="submit" name="submit">submit</button>
</form>

<?php

$query = "
SELECT * FROM test 
ORDER BY name DESC
";

$statement = $conn->prepare($query);

$statement->execute();

if($statement->rowCount() > 0)
{
    $result = $statement->fetchAll();
    foreach($result as $row)
    {
        $output .= '
        <tr>
            <td>'.$row["name"].'</td>
        </tr>
        ';
    }
}
else
{
    $output .= '
        <tr>
            <td>No Data Found</td>
        </tr>
    ';
}

?>
 <table class="table table-striped table-bordered">
                        <tr>
                            <td>Email Address</td>
                        </tr>
                        <?php
                        echo $output;
                        ?>
                    </table>